# ArchiDom Layout Studio — Full Package

Дата сборки: 4 августа 2026 года

Этот пакет является полной зафиксированной базой по двум направлениям:

1. RemPlanner — наблюдаемая пользователем функциональная схема, модули, листы, 2D/3D, развёртки, расчёты, сметы, версии, доступы и exports.
2. ArchiDom Layout Studio — целевая clean-room архитектура, KORA MVP, доменный контракт, задачи Codex, 10-дневный план и критерии принятия.

## Основные файлы

- ArchiDom_Layout_Studio_Master_Blueprint_2026-08-04.md — единый полный исходный документ.
- ArchiDom_Layout_Studio_Master_Blueprint_2026-08-04.docx — Word-версия.
- ArchiDom_Layout_Studio_Master_Blueprint_2026-08-04.pdf — версия для чтения.
- source/ — отдельные редактируемые исходные спецификации и JSON Schema.
- SHA256SUMS.txt — контрольные суммы файлов.

## Важная граница

Это clean-room specification. Пакет фиксирует доступные пользователю функции и самостоятельно спроектированную архитектуру. Он не содержит исходный код RemPlanner, закрытые API, proprietary-файлы .plan, чужие 3D-модели, текстуры или интерфейсные assets.

## Точка начала разработки

После owner GO открыть:

source/layout-studio-mvp/11_CODEX_START_PROMPT.md

и начать с LS-000 / Gate 0.

