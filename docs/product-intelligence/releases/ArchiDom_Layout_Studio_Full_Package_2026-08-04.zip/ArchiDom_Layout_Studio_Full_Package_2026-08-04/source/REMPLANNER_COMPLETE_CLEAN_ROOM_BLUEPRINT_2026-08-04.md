# ArchiDom Layout Studio — clean-room разбор RemPlanner и целевая архитектура v0.1

Дата: 4 августа 2026 года

Статус: **исследовательское предложение, не принято к реализации**

Владелец решения: Product / Architecture

Пилотный объект: KORA Food Hall, Liquid Station

Основание: наблюдение пользовательского интерфейса RemPlanner с активным тарифом «Собственный», официальные публичные материалы RemPlanner и фактическая архитектура ArchiDom.

## 0. Короткий вывод

Да, использовать RemPlanner как функциональный эталон проще и безопаснее, чем придумывать планировщик с чистого листа. Это сокращает:

- продуктовую неопределённость;
- количество пропущенных пользовательских сценариев;
- время на формирование требований;
- риск построить красивый, но непригодный для рабочего проекта редактор.

Но это **не снимает основную инженерную сложность**. Мы можем воспроизвести наблюдаемое поведение своим кодом, однако геометрическое ядро, синхронизацию 2D/3D, развёртки, расчёты, версии и экспорт всё равно необходимо разработать или лицензировать.

Рекомендуемая стратегия:

1. Не пытаться сразу повторить весь RemPlanner.
2. Использовать его как clean-room функциональную спецификацию.
3. Сначала построить узкий, но настоящий KORA vertical slice.
4. Встроить его в Память проекта ArchiDom, версии, provenance, согласования и M3 handoff.
5. Только после успешного пилота расширять редактор до квартир, домов и других коммерческих помещений.

Предварительная оценка:

| Уровень | Результат | Оценка |
|---|---|---:|
| Discovery + geometry spike | Проверка ядра на плане Liquid Station | 2–3 недели |
| KORA vertical slice | Рабочие 2D/3D, размеры, колонна, двери, техника, материалы, свет, версии и экспорт | 10–14 недель, команда 4–6 человек |
| Закрытая beta Layout Studio | Надёжная геометрия, этажи, варианты, каталог, развёртки, основные инженерные листы | 6–9 месяцев |
| Широкая функциональная сопоставимость | Большая часть наблюдаемого RemPlanner, расчёты, сметы, расширенный каталог и документы | 18–30 месяцев, ядро команды 8–12 человек |

Это ROM-оценка, а не обязательство. После geometry spike диапазон должен быть пересчитан.

## 1. Решение и граница документа

Документ описывает самостоятельный модуль **ArchiDom Layout Studio**:

- браузерный размерный 2D-планировщик;
- автоматическую производную 3D-сцену;
- автоматические развёртки стен;
- листы архитектуры, отделки и MEP;
- ведомости объёмов и предварительные сметы;
- версии, публикации и передачу результатов в M2/M3 ArchiDom.

Документ **не является разрешением начать разработку**. Текущий Product Charter v0.4 прямо фиксирует CAD/BIM и размерную геометрию как внешние возможности. Нативный Layout Studio меняет эту границу и требует:

1. отдельного ADR;
2. product/economics gate;
3. подтверждения команды и бюджета;
4. решения build versus license;
5. проверки 152-ФЗ и data-plane;
6. сохранения текущих P0-приоритетов authenticated pilot.

До принятия ADR RemPlanner остаётся внешним рабочим инструментом для KORA, а этот документ — архитектурой возможного следующего продукта.

## 2. Метод clean-room

### 2.1. Что разрешено

- наблюдать доступные пользователю экраны и сценарии;
- читать официальную документацию и маркетинговые страницы;
- фиксировать названия классов функций и пользовательские ожидания;
- самостоятельно проектировать собственную модель данных, UX и алгоритмы;
- использовать KORA как реальный acceptance fixture;
- воспроизводить общие отраслевые операции: стены, проёмы, размеры, слои, спецификации.

### 2.2. Что запрещено

- копировать исходный код, скрытые API, сетевые payload или внутренние форматы;
- обходить технические ограничения продукта;
- копировать тексты, иконки, 3D-модели, текстуры, UI-композицию или бренд;
- выдавать proprietary-формат .plan за наш формат;
- использовать чужие каталоги без лицензии;
- строить совместимость, которая требует обратной разработки закрытого формата;
- утверждать, что наша реализация использует те же алгоритмы.

### 2.3. Маркировка утверждений

В документе используются три класса:

- **OBSERVED** — непосредственно увидено в пользовательском интерфейсе или подтверждено официальной страницей.
- **INFERRED** — необходимое техническое следствие наблюдаемого поведения, но не знание о внутренностях RemPlanner.
- **RECOMMENDED** — наше целевое решение для ArchiDom.

## 3. Источники и степень доказанности

| Источник | Что подтверждает | Класс |
|---|---|---|
| Платный пользовательский интерфейс RemPlanner, тариф «Собственный», 04.08.2026 | Реальные экраны, инструменты, параметры, режимы, листы и экспорты | OBSERVED |
| KORA test project в RemPlanner | Работа 2D, генерация 3D, развёртки и расчёты на реальном плане | OBSERVED |
| Официальная страница PRO | 3D, материалы, расчёты, сметы, GLTF, отдельный сайт, субаккаунты | OBSERVED |
| Официальный FAQ и инструкция | .plan, PDF, гостевые ссылки, последовательность построения | OBSERVED |
| Ответ коммерческого представителя RemPlanner | Отсутствие подходящего API/SSO/white-label embedding для нашего процесса | OBSERVED, переписка пользователя |
| Product Charter v0.4 и Architecture v1 ArchiDom | Текущая граница продукта, версии, provenance, security и audit | OBSERVED |
| Разделы 7–18 этого документа | Предлагаемая самостоятельная реализация | RECOMMENDED |

Снимки приватного кабинета, email пользователя и закрытые ссылки проекта не должны публиковаться или попадать в публичные assets.

## 4. Что фактически представляет собой RemPlanner

RemPlanner — не одна 3D-картинка. Наблюдаемая система состоит из взаимосвязанных частей:

1. проект, этажи и варианты планировки;
2. каноническая размерная 2D-модель;
3. набор тематических листов;
4. каталог архитектурных и инженерных объектов;
5. автоматическая 3D-проекция;
6. автоматические развёртки стен;
7. движок объёмов и метражей;
8. смета работ и материалов;
9. документы и обмен;
10. версии, резервные копии и гостевые доступы;
11. AI-рендер как дополнительный downstream-процесс;
12. коммерческая оболочка с брендингом и дочерними аккаунтами.

Главный архитектурный вывод: **источником истины должна быть единая размерная сцена**, а 2D-листы, 3D, развёртки, ведомости и PDF — производные представления одной версии.

## 5. Полная карта наблюдаемых возможностей

### 5.1. Проекты и доступ

**OBSERVED**

- создание проекта;
- название, номер, версия и площадь;
- несколько этажей;
- несколько вариантов планировки;
- копирование проекта;
- резервные копии;
- ссылки на просмотр и редактирование;
- загрузка и выгрузка внутреннего файла .plan;
- срок действия тарифа;
- лимит проектов;
- дочерние аккаунты;
- предоплаченные лицензии;
- отдельный брендированный сайт на поддомене floorplan.tools;
- настройка логотипа, контактов и элементов оболочки.

**Вывод для ArchiDom**

Проект Layout Studio не должен быть отдельным островом. Он является capability внутри существующих Organization, Project, Package и Role contracts ArchiDom.

### 5.2. Рабочее поле 2D

**OBSERVED**

- сетка и размерная сцена;
- единицы в сантиметрах;
- перемещение и масштабирование;
- выбор объектов;
- контекстные операции;
- точные числовые параметры;
- автоматические размерные подписи;
- площадь помещений;
- undo/redo;
- удаление;
- управление отображением;
- рисование произвольных элементов;
- текстовые комментарии;
- шаг перемещения 1, 2, 5 или 10 мм;
- центрирование и поворот вида;
- переключение 2D / стены / 3D;
- экспорт текущего листа в PNG и SVG.

### 5.3. Канонические архитектурные объекты

**OBSERVED**

- стены и сегменты;
- балконы;
- окна;
- двери и проёмы;
- колонны;
- потолочные балки;
- лестницы;
- отверстия в перекрытиях;
- инженерные стояки/вводы;
- террасы и участки;
- помещения и зоны.

Параметры включают длину, ширину, глубину, высоту, толщину, материал, привязку и положение относительно родительской конструкции.

### 5.4. Операции с объектами

**OBSERVED**

- переместить;
- копировать;
- удалить;
- изменить модель;
- изменить фасад;
- изменить ручку и её положение;
- отразить фасад;
- принудительно скрыть;
- запретить автоматическое скрытие;
- рисовать вручную или по заданному размеру;
- редактировать размеры составных модулей.

### 5.5. Планировочные листы

В обследованном проекте доступны следующие листы:

| № | Лист |
|---:|---|
| 1 | Исходный план |
| 2 | Демонтаж |
| 3 | Перегородки |
| 4 | Помещения |
| 5 | Радиаторы |
| 6 | Мебель |
| 7 | Сантехника |
| 8 | Водоснабжение |
| 9 | Розетки |
| 10 | Выключатели |
| 11 | Освещение |
| 12 | Электропроводка |
| 13 | Электрощиток |
| 14 | Тёплые полы |
| 15 | Кондиционеры |
| 16 | Вентиляция |
| 17 | Безопасность |
| 18 | Напольные покрытия |
| 19 | Отделка стен |
| 20 | Потолки |
| 21 | Гидроизоляция |
| 22 | Изоляция |
| 23 | Штукатурка |
| 24 | Развёртки стен |
| 25 | Стяжка |

Также наблюдалась возможность добавить пользовательский лист.

### 5.6. Демонтаж и перегородки

**OBSERVED**

Демонтаж:

- стена;
- сегмент;
- проём;
- радиатор;
- электрощит;
- отмена демонтажа.

Перегородки:

- ПГП;
- пеноблок;
- кирпич;
- гипсокартон;
- стекло;
- реечная перегородка;
- короб из гипсокартона;
- зонирование.

### 5.7. Мебель, оборудование и сантехника

**OBSERVED**

Каталог мебели разделён как минимум на:

- гостиные и спальни;
- кухни и столовые;
- бытовую технику;
- гардеробные и прихожие;
- детские;
- офис;
- декор;
- фитнес;
- коттеджи и сауны;
- салоны красоты;
- торговые помещения;
- рестораны и кафе;
- медицинские помещения;
- промышленное оборудование;
- автосервис.

Сантехника:

- раковины;
- мебель ванной;
- бытовые приборы;
- ванны;
- унитазы и биде;
- душевые;
- смесители и душевые системы;
- полотенцесушители;
- аксессуары.

### 5.8. Электрика

**OBSERVED**

Розетки и точки:

- 220 В;
- группы розеток;
- IP44;
- слаботочные;
- выводы провода;
- силовые 220/380 В;
- напольные и потолочные;
- оборудование;
- щиты.

Выключатели:

- одно-, двух- и трёхклавишные;
- диммеры;
- проходные и перекрёстные;
- мастер-выключатель;
- линия связи.

Освещение:

- потолочные люстры;
- потолочные светильники;
- споты;
- настенный свет;
- треки;
- линейный свет;
- LED.

Проводка и щиты:

- 2/3/4/5-жильные кабели;
- слаботочные линии;
- заземление;
- распределительные коробки;
- узлы;
- DIN-рейки;
- автоматы и защитные устройства;
- шины;
- фазная, нулевая и земляная разводка.

### 5.9. Вода, отопление, HVAC и безопасность

**OBSERVED**

Вода:

- холодная и горячая точки;
- канализация;
- коллекторы;
- трассы ХВС/ГВС;
- комбинированные выводы;
- узлы.

Отопление:

- радиаторы и конвекторы;
- коллекторные узлы;
- подающая и обратная магистраль.

Тёплые полы:

- кабельные;
- инфракрасные;
- тёплая стена;
- водяной пол;
- термостаты;
- соединительные линии;
- коллекторы.

HVAC:

- внутренние и наружные блоки кондиционеров;
- дренаж;
- фреоновая трасса;
- приточные и вытяжные каналы;
- решётки и диффузоры;
- вентиляторы;
- оборудование.

Безопасность:

- пожарные элементы;
- CCTV;
- датчики движения, света и протечки;
- панели протечки и сигнализации.

### 5.10. Отделка

**OBSERVED**

Полы:

- ламинат и винил;
- дерево и паркет;
- плитка;
- другие покрытия;
- плинтус;
- начальная точка укладки;
- зонирование.

Стены:

- обои и краска;
- плитка и камень;
- панели и рейки;
- декоративная штукатурка;
- комбинированная отделка.

Потолки:

- финишное покрытие;
- двухуровневые конструкции;
- зонирование;
- карнизная ниша;
- закладные;
- карнизы;
- отверстия.

Дополнительные слои:

- гидроизоляция пола и стен;
- минеральная вата;
- Penoplex;
- ЗИПС;
- Soundline;
- мембраны;
- рулонная изоляция;
- штукатурка по правилу и маякам;
- пескобетонная, полусухая, сухая и наливная стяжка.

### 5.11. Развёртки стен

**OBSERVED**

- помещение выбирается на плане;
- стены автоматически нумеруются;
- строится непрерывный набор боковых проекций;
- на развёртки попадают двери, окна, мебель, электрика и инженерные объекты;
- есть режимы «Отделка и декор» и «Мебель и инженерия»;
- доступны размеры;
- имеются инструменты линейного света, разделительного профиля, молдинга, ниши и стартовой точки плитки.

**INFERRED**

Развёртка является детерминированной проекцией канонической сцены и не должна храниться как независимый ручной чертёж.

### 5.12. 3D

**OBSERVED**

- 3D автоматически строится из 2D;
- WebGL-сцена;
- скрытие стен выше 1 м;
- показ мебели и оборудования;
- показ розеток и выключателей;
- показ потолочного освещения;
- виртуальный тур;
- настройка теней и фона;
- стандартная, изометрическая и широкоугольная камера;
- свободный угол и фиксированные 90/45/30/0 градусов;
- навигация по сцене и мини-карта;
- снимки 3:2, 1:1, 2:3 и размером экрана;
- экспорт GLTF 2.0 / GLB с моделями и материалами;
- варианты экспорта с потолками и без них.

Материалы:

- дерево;
- краска;
- металл;
- ткань;
- обои;
- плитка;
- кожа;
- ковры;
- камень;
- бетон;
- кирпич;
- панели;
- стекло;
- другое;
- RAL Classic и NCS;
- матовый/глянцевый вариант;
- поиск по коду;
- личная палитра.

Декор:

- картины и рамки;
- книги и журналы;
- ковры;
- подушки и пледы;
- растения и вазы;
- свет;
- настенный и настольный декор;
- декор кухни, ванной и детской;
- животные;
- аксессуары;
- одежда и обувь;
- электроника;
- сауна;
- праздничный декор.

### 5.13. AI-рендер

**OBSERVED**

- рендер запускается из выбранной камеры 3D;
- выбор наличия окон и вида из окна;
- утро/день/вечер/ночь;
- сезон;
- погода;
- окружение: город/лес/сад;
- управление освещением;
- пользовательский prompt;
- асинхронная задача;
- галереи активных, удалённых и отменённых результатов;
- кредитная модель оплаты.

**Вывод**

AI-рендер не является геометрическим ядром. Он получает производную сцену/камеру и возвращает визуальный artifact. Его нужно строить последним через сменяемый provider adapter.

### 5.14. Объёмы и метражи

**OBSERVED**

Общие:

- площадь пола;
- площадь стен;
- площадь террас;
- периметр пола и потолка;
- площадь новых и декоративных перегородок.

Окна и двери:

- количество;
- площадь остекления;
- периметр откосов;
- длина подоконников;
- площадь дверных откосов.

Отделка:

- площади покрытий пола, стен и потолка;
- периметр плинтуса;
- площадь и длина карнизных ниш;
- периметр молдингов.

Электрика:

- общее количество точек;
- розетки, слаботочка, выключатели, термостаты;
- выводы и коробки;
- зоны и площадь тёплого пола;
- светильники;
- длины треков и линейного света;
- длины силовых, слаботочных и заземляющих линий;
- CCTV и датчики.

Вода, отопление и HVAC:

- трубы тёплого пола;
- радиаторы;
- подача и обратка;
- выводы ХВС/ГВС/канализации;
- блоки кондиционирования;
- дренаж;
- вентиляторы и решётки;
- длины приточных и вытяжных каналов.

Интерфейс позволяет группировать значения по помещениям и скрывать пустые строки.

### 5.15. Смета работ и материалов

**OBSERVED**

Смета работ связывает:

проектное количество × редактируемая расценка = сумма.

Разделы:

- демонтаж;
- черновые работы;
- сантехника;
- плитка;
- электрика;
- предчистовая подготовка;
- малярные работы;
- чистовые работы;
- дополнительные позиции.

Смета материалов содержит:

- название;
- расчётное количество;
- количество упаковок;
- вес;
- цену;
- сумму;
- магазин/ссылку;
- вспомогательные материалы.

Некоторые расчёты требуют наличия конкретного исходного объекта, например стояка.

### 5.16. Выходные документы

**OBSERVED**

- PDF-альбом;
- PNG текущего листа;
- SVG текущего листа;
- GLB;
- внутренний .plan;
- публичные ссылки просмотра/редактирования;
- резервные копии;
- листы с рамкой, штампом, форматом и ориентацией.

Для ArchiDom открытыми обменными форматами должны стать собственный versioned JSON, SVG, PDF, PNG и GLB. Закрытый .plan не является нашей интеграционной целью.

## 6. Ключевые пользовательские сценарии

### J1. Построить существующий план

1. Создать проект.
2. Добавить этаж и высоту.
3. Загрузить план-подложку.
4. Откалибровать масштаб по известному размеру.
5. Нарисовать стены.
6. Добавить двери, окна, колонны, балки и проёмы.
7. Проверить замкнутость помещений и площади.
8. Сохранить исходную версию.

### J2. Создать вариант планировки

1. Копировать исходный вариант.
2. Отметить демонтаж.
3. Добавить перегородки.
4. Назначить помещения.
5. Расставить мебель и оборудование.
6. Проверить проходы и коллизии.
7. Сохранить вариант с причиной изменения.
8. Отправить на review.

### J3. Спроектировать инженерные точки

1. Открыть нужный дисциплинарный лист.
2. Разместить точки и оборудование.
3. Связать точку с родителем/помещением/высотой.
4. Проложить трассы и цепи.
5. Проверить правила и коллизии.
6. Получить ведомость.
7. Выпустить exact revision для M3.

### J4. Сделать 3D и подобрать материалы

1. Открыть 3D из той же версии.
2. Назначить материалы поверхностям и объектам.
3. Настроить свет и камеру.
4. Сделать снимок или GLB.
5. При необходимости отправить снимок в AI renderer.
6. Вернуть результат как artifact с provenance.

### J5. Выпустить пакет

1. Выбрать exact geometry revision.
2. Выбрать листы.
3. Проверить комплектность.
4. Сгенерировать PDF/SVG/ведомости/GLB.
5. Зафиксировать semantic manifest.
6. Опубликовать immutable package.
7. Передать архитектору/подрядчику и зафиксировать получение.

## 7. Целевая системная архитектура

~~~mermaid
flowchart LR
  User["Пользователь M2/M3"] --> Shell["ArchiDom Workspace Shell"]
  Shell --> Editor["Layout Studio Editor"]

  Editor --> Commands["Command + Undo/Redo Engine"]
  Commands --> Geometry["2D Geometry Kernel"]
  Geometry --> Topology["Room & Surface Topology"]

  Topology --> Scene["3D Scene Compiler"]
  Topology --> Elevation["Elevation Generator"]
  Topology --> Sheets["Sheet Projection Engine"]
  Topology --> Quantity["Quantity & Rules Engine"]

  Catalog["Catalog + Asset Pipeline"] --> Editor
  Catalog --> Scene
  Rates["Rate Cards"] --> Estimate["Estimate Engine"]
  Quantity --> Estimate

  Editor --> Revision["Revision Service"]
  Revision --> Memory["ArchiDom Project Memory"]
  Memory --> Release["Baseline / Release / Handoff"]

  Scene --> Export["Export Workers"]
  Elevation --> Export
  Sheets --> Export
  Quantity --> Export
  Export --> Storage["Object Storage"]

  Scene --> AI["Optional AI Render Adapter"]
  AI --> Storage
~~~

### 7.1. Архитектурная форма

**RECOMMENDED**

На первой стадии — модульный монолит с выделенным browser editor package и worker-процессами для тяжёлых экспортов.

Не создавать микросервис на каждый лист. Разделять:

- domain packages;
- application commands;
- persistence adapters;
- export/render workers;
- UI composition.

Выносить отдельный сервис только при доказанном профиле нагрузки или независимом lifecycle.

### 7.2. Bounded contexts

| Контекст | Ответственность |
|---|---|
| Project Enrollment | Organization, Project, Package, Role, grants |
| Layout Document | этажи, варианты, единицы, настройки проекта |
| Geometry | стены, узлы, проёмы, колонны, помещения, поверхности |
| Placement | мебель, оборудование, декор, привязки |
| MEP | точки, трассы, цепи, системы и инженерные правила |
| Finishes | назначения материалов и покрытий |
| Views | 2D-листы, развёртки, 3D-камеры |
| Catalog | определения объектов, параметрические модели, лицензии |
| Measurement | площади, периметры, длины, количества |
| Estimation | нормы расхода, расценки, цены, допуски |
| Revision | команды, snapshots, версии, diff, audit |
| Publication | manifests, PDF/SVG/PNG/GLB, baseline и release |
| AI Render | задания, credits, provider provenance, artifacts |

## 8. Каноническая доменная модель

### 8.1. Контейнеры

| Entity | Ключевые поля |
|---|---|
| Organization | id, policy, locale, unitSystem |
| Project | id, organizationId, name, status |
| LayoutDocument | id, projectId, schemaVersion, canonicalUnits |
| Floor | id, documentId, elevationMm, clearHeightMm, order |
| LayoutVariant | id, floorId, parentVariantId, name, status |
| DraftState | variantId, stateRevision, geometrySnapshotId |
| PublishedGeometryVersion | id, variantId, exactSnapshotId, semanticHash |

### 8.2. Геометрия

| Entity | Назначение |
|---|---|
| GeometryNode | стабильная точка X/Y в целых миллиметрах |
| WallSegment | связь двух nodes, толщина, высота, тип, материал |
| Opening | дверь/окно/проём, привязанный к wall segment |
| Column | параметрическое сечение, позиция, высота |
| Beam | линия/сечение/отметка |
| SlabOpening | полигон отверстия |
| Room | вычисленный замкнутый контур и ручная семантика |
| Surface | производная поверхность пола/стены/потолка |
| Zone | пользовательский контур без требования замкнутой комнаты |
| ReferenceImage | подложка, calibration transform, provenance |

Канонические координаты и размеры хранятся в **целых миллиметрах**. Display units не меняют данные.

### 8.3. Объекты и каталоги

| Entity | Назначение |
|---|---|
| CatalogAsset | тип объекта, параметры, bounding box, лицензия |
| AssetVariant | модель/фасад/ручка/LOD |
| PlacedObject | экземпляр с transform и родителем |
| Anchor | привязка к стене, полу, потолку, поверхности или объекту |
| ClearanceVolume | обязательная сервисная/проходная зона |
| MaterialDefinition | PBR-параметры, цветовые системы, лицензия |
| MaterialAssignment | material → surface/object exact revision |
| UserLibraryItem | собственный параметрический блок пользователя |

### 8.4. MEP

| Entity | Назначение |
|---|---|
| MEPSystem | electrical, lighting, water, sewer, HVAC, safety |
| MEPNode | точка/оборудование/панель/коллектор |
| MEPPort | connection point с типом среды |
| MEPRoute | полилиния трассы, отметка, диаметр/сечение |
| Circuit | электрическая цепь и параметры нагрузки |
| ControlLink | выключатель → светильник и другие логические связи |
| Penetration | проход через стену/перекрытие |
| RuleViolation | детерминированная ошибка или предупреждение |

### 8.5. Представления и документы

| Entity | Назначение |
|---|---|
| SheetDefinition | дисциплина, фильтры, style preset |
| Viewport | вид, масштаб, crop и layout на листе |
| Dimension | associative dimension по stable geometry refs |
| Annotation | текст/выноска/условное обозначение |
| ElevationView | roomId, wall sequence, projection settings |
| Camera | позиция, target, lens, clipping |
| ExportJob | формат, exact version, параметры, status |
| ExportArtifact | storage key, checksum, mime, size |
| ReleaseManifest | exact inputs, outputs, hashes, author, time |

### 8.6. Расчёты

| Entity | Назначение |
|---|---|
| QuantityDefinition | формула, unit, required inputs |
| QuantityResult | exact version, scope, value, trace |
| WasteRule | коэффициент запаса и условия |
| RateCard | организация, регион, валюта, дата |
| WorkItem | quantity × rate |
| MaterialRule | нормы упаковки и расхода |
| EstimateVersion | immutable snapshot расчёта |

## 9. Геометрическое ядро

### 9.1. Обязательные инварианты

1. Нет сегментов нулевой длины.
2. Координаты и размеры детерминированы.
3. Opening всегда лежит на существующей стене и не выходит за её границы.
4. Колонна — самостоятельный объект от пола до заданной отметки, а не часть мебели.
5. Room создаётся только из валидного замкнутого контура.
6. Площадь и периметр одной версии воспроизводимы.
7. Изменение стены пересчитывает связанные openings, rooms, surfaces и dimensions.
8. Derived view не может редактировать каноническую геометрию в обход command engine.
9. Удаление родителя либо запрещается, либо даёт явный impact и controlled cascade.
10. Одна и та же команда с тем же idempotency key не создаёт двойное изменение.

### 9.2. Топология

**RECOMMENDED**

Геометрия хранится как planar graph:

- nodes — стабильные вершины;
- edges — осевые линии стен;
- wall profile — толщина и смещение;
- faces — вычисленные помещения;
- half-edge representation — кандидат для устойчивого обхода контуров;
- openings — параметры вдоль родительского edge;
- surface mesh — производный результат.

Для первой KORA-версии допустим ограниченный orthogonal-first kernel, но формат данных не должен запрещать произвольные углы и дуги в будущем.

### 9.3. Snapping и ограничения

- endpoint;
- midpoint;
- intersection;
- perpendicular;
- parallel;
- grid;
- wall face/axis;
- object anchor;
- numeric distance;
- numeric angle;
- temporary guides.

Все snaps возвращают не только координату, но и provenance привязки, чтобы размер оставался ассоциативным.

### 9.4. Команды

Примеры:

- CreateWall;
- MoveNode;
- SplitWall;
- ChangeWallProfile;
- PlaceOpening;
- PlaceColumn;
- CreateZone;
- PlaceCatalogObject;
- AssignMaterial;
- ConnectMEPRoute;
- AddDimension;
- PublishGeometryVersion.

Команда содержит:

- actor context, полученный server-side;
- project/document/variant scope;
- idempotency key;
- expected state revision;
- controlled reason;
- payload;
- client command id.

### 9.5. Undo/redo

Внутри открытой сессии — обратимые команды. На сервере — append-only command/audit record плюс периодические snapshots.

Undo не удаляет опубликованную историю. После publication новое изменение создаёт новую draft revision.

## 10. Производные представления

### 10.1. Компиляция 2D → 3D

Pipeline:

1. валидировать graph;
2. построить faces помещений;
3. экструзировать стены;
4. вычесть openings;
5. построить полы и потолки;
6. разместить параметрические объекты;
7. назначить материалы;
8. расставить lighting proxies;
9. собрать scene graph;
10. создать LOD и collision meshes;
11. вывести WebGL и/или GLB.

3D-сцена должна содержать ссылки обратно на stable IDs, чтобы выбор объекта в 3D выделял тот же объект в 2D.

### 10.2. Развёртки

Pipeline:

1. выбрать exact room face;
2. определить упорядоченный обход стен;
3. для каждой стены вычислить локальную систему координат;
4. спроецировать openings, отделку, мебель и MEP;
5. применить visibility rules;
6. построить associative dimensions;
7. собрать непрерывный elevation strip или отдельные views.

### 10.3. Листы

Лист — не копия геометрии. Это:

- фильтр классов объектов;
- discipline style;
- visibility rules;
- annotations;
- viewports;
- scale;
- title block;
- exact source version.

Так один object может появляться на нескольких листах, не создавая дубликатов.

### 10.4. Ведомости

Каждая строка результата обязана иметь trace:

- formula version;
- input entity IDs;
- exact geometry version;
- room/discipline scope;
- unit conversion;
- rounding;
- waste factor;
- warnings.

Пользователь должен видеть не только число, но и «из чего оно получилось».

## 11. Хранение и версионирование

### 11.1. Рекомендуемая схема

PostgreSQL:

- identity, tenancy и ACL;
- документы, этажи, варианты и статусы;
- stable entity metadata;
- revisions, commands, audit;
- расчётные результаты;
- manifests и jobs.

Object Storage:

- reference images;
- geometry snapshots;
- catalog binaries;
- textures;
- GLB;
- PDF/PNG/SVG;
- AI-render inputs/outputs.

Возможна комбинация:

- нормализованные поля для identity, ownership и query;
- versioned JSON/MessagePack snapshot для быстрой загрузки редактора;
- отдельный append-only command log;
- immutable publication snapshot.

Один огромный mutable JSONB без stable IDs, ревизий и атомарного commit запрещён.

### 11.2. Связь с Project Intelligence

Layout Studio использует существующие инварианты Architecture v1:

- stable identity;
- immutable revisions;
- exact version review;
- optimistic concurrency;
- idempotency;
- atomic state + audit commit;
- deterministic diff/impact;
- server-derived actor/organization/project/package/role;
- immutable released package.

Geometry entities становятся новым типом source-linked nodes в Project Memory. PublishedGeometryVersion может быть input M2 Approved Design Intent и M3 Released Production Package.

### 11.3. Publication

При публикации фиксируются:

- schema version;
- exact geometry snapshot checksum;
- catalog asset revisions;
- material revisions;
- sheet definitions;
- calculation rules;
- exported artifacts;
- semantic hash;
- human author and reason;
- source provenance.

Смена цены товара не меняет уже выпущенную геометрию. Она создаёт новое ценовое наблюдение и, при необходимости, новый estimate version.

## 12. Доступ, совместная работа и безопасность

### 12.1. Роли

Минимум:

- owner;
- editor;
- reviewer;
- viewer;
- contractor receiver;
- guest.

Возможность определяется capability, а не названием экрана.

### 12.2. Правила

- RLS deny-by-default;
- actor и scope только server-side;
- публичные grants хэшированные, scoped, expiring, revocable;
- signed URLs не более 15 минут по текущему контракту;
- source filename не включается в public key;
- audit append-only;
- опубликованные версии immutable;
- AI не публикует и не согласует;
- все export jobs привязаны к exact version;
- renderer не получает данные другого проекта;
- каталожные лицензии проверяются до выдачи asset;
- чувствительные планы и изображения не попадают в telemetry.

### 12.3. Совместное редактирование

Этап 1: optimistic locking на уровне document revision и single-writer editing session.

Этап 2: presence, soft locks по выбранным объектам, comments.

Этап 3: CRDT/OT только после измеренного спроса. Полноценная одновременная геометрическая редактура не должна быть условием первого релиза.

## 13. Технический стек

### 13.1. Сохраняем

- Next.js и TypeScript strict для shell и server delivery;
- React для workspace composition;
- Supabase/PostgreSQL/Auth/Storage как текущий adapter до data residency gate;
- Vitest;
- Vercel для нынешнего web cell до отдельного решения;
- layered modular monolith;
- provider ports.

Фактический репозиторий на 04.08.2026 использует Next.js 16.2, React 18.3, Supabase JS/SSR и Vitest 4.1. Это необходимо учитывать вместо устаревшего упоминания Next.js 14.

### 13.2. Добавляем только после spike

Рекомендуемые кандидаты, не финальный выбор:

- PixiJS или собственный WebGL/Canvas scene layer для 2D;
- Three.js для 3D;
- Web Workers для topology, tessellation и calculations;
- robust geometry predicates и polygon clipping library после benchmark;
- glTF 2.0 как основной внешний формат сцены;
- off-main-thread export jobs;
- очередь заданий для PDF/GLB/AI.

Почему не обычный DOM/SVG как единственный canvas:

- большие сцены;
- частое перемещение;
- hit testing;
- тысячи объектов;
- сложные overlays;
- необходимость единого render loop.

SVG остаётся отличным экспортным форматом и может использоваться для отдельных views, но не обязан быть основным интерактивным renderer.

### 13.3. Изоляция редактора

Предлагаемая структура:

~~~text
packages/layout-domain/
packages/layout-geometry/
packages/layout-commands/
packages/layout-calculation/
packages/layout-scene/
packages/layout-export-contracts/
components/layout-studio/
lib/project-intelligence/adapters/layout/
workers/layout-export/
~~~

Domain packages не импортируют Next.js, Supabase, React, Three.js или UI.

## 14. API и application contracts

Минимальные server operations:

- createLayoutDocument;
- createFloor;
- createLayoutVariant;
- loadDraftSnapshot;
- commitGeometryCommands;
- createCheckpoint;
- publishGeometryVersion;
- requestExport;
- getExportStatus;
- createShareGrant;
- revokeShareGrant;
- calculateQuantities;
- createEstimateVersion;
- attachArtifactToProjectMemory.

Mutation contract:

~~~text
CommandEnvelope
  requestId
  idempotencyKey
  documentId
  variantId
  expectedStateRevision
  commandBatch
  reasonCode
  reason
~~~

Server response:

~~~text
CommitResult
  stateRevision
  appliedCommandIds
  snapshotRef
  validationIssues
  derivedInvalidations
  auditEventIds
~~~

DerivedInvalidations сообщают, что необходимо пересчитать: rooms, surfaces, 3D, elevations, quantities, sheets или estimates.

## 15. Производительность и надёжность

Цели первого production-кандидата:

| Метрика | Цель |
|---|---:|
| Реакция drag/snapping | p95 менее 16–32 мс на поддерживаемой сцене |
| Применение простой команды | менее 100 мс client-side |
| Autosave batch | не блокирует UI |
| Открытие KORA layout | менее 3 сек на целевом ноутбуке после cache |
| Пересчёт одной комнаты | менее 300 мс |
| Полный пересчёт KORA | менее 2 сек |
| 3D first useful frame | менее 5 сек |
| Потеря подтверждённых изменений | 0 при успешном commit |
| Повтор idempotent request | тот же logical result |

Обязательные механизмы:

- autosave;
- offline command buffer на короткий разрыв;
- checkpoint до миграции schema;
- recoverable export jobs;
- deterministic replay;
- memory budget и asset LOD;
- telemetry без содержимого проекта;
- feature flags;
- kill switch для AI/provider.

## 16. Тестовая стратегия

### 16.1. Unit и property-based tests

- пересечение и разбиение стен;
- room face extraction;
- offset стен;
- openings;
- площади и периметры;
- unit conversion;
- snapping;
- transforms;
- calculation formulas;
- command inverse;
- canonical hash.

Property examples:

- площадь не отрицательна;
- undo(command(state)) возвращает semantic-equivalent state;
- serialize/deserialize сохраняет semantic hash;
- порядок независимых команд не меняет результат там, где это разрешено;
- derived surfaces не содержат NaN/Infinity;
- повторный commit идемпотентен.

### 16.2. Golden fixtures

Обязательные:

- простая прямоугольная комната;
- L-shaped room;
- две комнаты с общей стеной;
- проёмы рядом с узлом;
- колонна внутри помещения;
- несколько этажей;
- KORA Liquid Station;
- внешний жилой пакет.

Для каждой fixture:

- canonical JSON hash;
- rooms/areas;
- SVG snapshot;
- 3D mesh statistics;
- elevation snapshots;
- quantity results;
- expected warnings.

### 16.3. Visual и browser QA

- Chrome, Safari и Edge;
- retina и обычный экран;
- zoom;
- keyboard-only numeric entry;
- touch не является P0, если не принято отдельно;
- WebGL context loss/recovery;
- screenshot comparison;
- GLB validation;
- PDF page regression.

### 16.4. Security

- cross-organization;
- cross-project;
- sibling package;
- stale revision;
- expired/revoked guest grant;
- signed URL TTL;
- catalog entitlement;
- export job scope;
- malicious uploaded SVG/image;
- oversized models/textures;
- AI prompt and artifact isolation.

## 17. KORA Liquid Station — первый vertical slice

### 17.1. Обязательный scope

Редактор должен позволить без обходных манёвров:

- построить фактический контур Tenant 12;
- сохранить существующие стены и двери;
- задать реальную высоту помещения;
- поставить отдельную колонну 25 × 25 см от пола до потолка;
- разместить колонну по измеренным координатам;
- разместить центральную двойную мойку независимо от колонны;
- разместить реальную линейку оборудования по задней стене;
- использовать пользовательские параметрические блоки по XLSX;
- задать барную стойку и технологические проходы;
- назначить матовый polished concrete и индонезийскую декоративную плитку;
- назначить материалы стены, металла и патины;
- задать рабочее и декоративное освещение;
- проложить видимые декоративные трубы/свет как отдельные объекты;
- показать закрытые стороны помещения и доступ только через существующие двери;
- получить 2D, 3D и как минимум одну развёртку;
- сохранить две версии и показать diff;
- выгрузить PNG, SVG, GLB и краткий PDF;
- передать exact version в M3.

### 17.2. Что не входит в первый slice

- все 25 листов;
- сложный электрощит;
- автоматическая рыночная смета;
- тысячи каталожных моделей;
- realtime multi-user;
- мобильный редактор;
- BIM/IFC authoring;
- DWG authoring;
- фотореалистичный renderer;
- AI, который меняет геометрию;
- полный аналог коммерческого white-label RemPlanner.

### 17.3. Acceptance criteria

1. План соответствует контрольным размерам, включая расстояние до стены 3 м, если это подтверждено исходным чертежом.
2. Колонна имеет размер 250 × 250 мм и не пересекает барную стойку или мойку.
3. Двери остаются на фактических местах.
4. Оборудование сохраняет габариты и последовательность по ведомости.
5. 2D, 3D и развёртки показывают одну и ту же версию.
6. Изменение стены или объекта обновляет зависимые размеры и 3D.
7. Экспорт содержит manifest exact revision.
8. Архитектор может открыть выдачу без доступа к draft.

## 18. Этапы реализации

### Phase 0 — Evidence freeze и geometry spike, 2–3 недели

Результаты:

- нормализованный KORA plan fixture;
- контрольные размеры;
- schema v0;
- wall/node/opening/column kernel;
- room detection;
- простой canvas;
- простая экструзия 3D;
- benchmark;
- решение build/license;
- уточнённая оценка.

Gate:

- одна и та же сцена строит корректный 2D contour, площадь и узнаваемый 3D;
- нет ручного дублирования данных.

### Phase 1 — KORA vertical slice, 10–14 недель

- редактор стен, проёмов и колонн;
- точные размеры и snaps;
- parametric equipment blocks;
- materials;
- basic lighting;
- 3D navigation;
- PNG/SVG/GLB/PDF;
- drafts, checkpoints и published version;
- ArchiDom Project Memory handoff;
- access and audit.

### Phase 2 — Layout beta, ещё 3–5 месяцев

- произвольные углы;
- этажи и варианты;
- расширенный каталог;
- reference-image calibration;
- undo/redo hardening;
- comments/review;
- room/finish sheets;
- automatic elevations;
- quantity baseline;
- performance hardening.

### Phase 3 — Production documentation, ещё 4–6 месяцев

- demolition/partition;
- electrical;
- lighting;
- plumbing;
- HVAC;
- associative dimensions;
- complete PDF albums;
- MEP rules;
- conflict and completeness checks;
- release packages.

### Phase 4 — Estimates and ecosystem, ещё 3–5 месяцев

- rate cards;
- work estimates;
- material formulas;
- supplier observations;
- user library;
- catalog governance;
- commercial entitlements.

### Phase 5 — AI and advanced collaboration

- render provider;
- controlled generative assistance;
- realtime collaboration, если подтверждён спрос;
- advanced rule explanation;
- tenant-specific templates.

## 19. Команда

Минимум для KORA slice:

- 1 lead/geometry engineer;
- 1 frontend graphics engineer;
- 1 full-stack/application engineer;
- 1 product designer with CAD workflow experience;
- fractional QA;
- fractional 3D technical artist/asset engineer.

Для широкой beta:

- 2 geometry/graphics engineers;
- 2 frontend/workspace engineers;
- 2 backend/platform engineers;
- 1 3D asset pipeline engineer;
- 1 QA automation;
- 1 product designer;
- 1 product/architecture owner.

Самый высокий риск — не обычный CRUD, а geometry kernel и профессиональный UX точного редактирования.

## 20. Build versus license gate

До Phase 1 сравнить три пути:

| Путь | Плюсы | Минусы |
|---|---|---|
| Полностью свой kernel | Контроль, глубокая связь с Project Memory, независимость | Самая высокая стоимость и риск |
| Лицензированный SDK/kernel | Быстрее geometry/3D baseline | Лицензия, lock-in, ограничения data plane и UX |
| Внешний planner adapter | Самый быстрый старт | Нет единого UX, слабый provenance, vendor dependency |

RemPlanner не подходит как embedded engine по имеющемуся ответу поставщика: нет нужной модели API/SSO/интеграции. Его следует использовать как временный внешний инструмент и functional benchmark.

Решение о собственном kernel принимается только после:

- benchmark KORA;
- проверки лицензируемых SDK;
- оценки data residency;
- проверки форматов и прав на catalog assets;
- расчёта стоимости поддержки на 3 года.

## 21. Как Layout Studio усиливает ArchiDom

Если просто повторить RemPlanner, мы получим ещё один планировщик. Ценность ArchiDom появляется в связке:

| Обычный планировщик | ArchiDom Layout Studio |
|---|---|
| Файл проекта | Project Memory |
| Последняя сохранённая версия | Exact immutable revisions |
| Ручная передача PDF | Released Production Package |
| Комментарии отдельно | Review exact revision |
| Изменение без контекста | Who / when / why + ChangeSet |
| Неясное влияние | Deterministic impact |
| Каталог без происхождения | Provenance, дата, цена, права |
| 3D как картинка | Derived view канонической геометрии |
| AI-рендер как результат | Artifact с input version и provider provenance |

Именно этот слой является нашим отличием; визуальное копирование интерфейса RemPlanner отличием не является.

## 22. Основные риски

| Риск | Вероятность/влияние | Снижение |
|---|---|---|
| Недооценка geometry kernel | Высокие | Spike, ограниченный scope, geometry lead |
| Расползание до полного CAD/BIM | Высокие | Явные non-goals, gates |
| Копирование чужого IP | Средние/высокие | Clean-room log, собственные UX/assets/code |
| Некачественные 3D-assets | Высокие | Asset pipeline, LOD, licensing |
| 2D/3D рассинхронизация | Высокие | Одна каноническая модель |
| Ошибочные ведомости | Высокие | Traceable formulas, golden fixtures, human review |
| Производительность браузера | Средние/высокие | Workers, spatial index, LOD, benchmark |
| Нарушение текущего P0 | Высокие | Отдельный ADR и отдельная команда/бюджет |
| 152-ФЗ/data residency | Высокие | Отдельный legal/infra gate |
| Vendor lock-in AI/catalog | Средние | Provider ports, versioned observations |
| Попытка сделать mobile-first editor | Средние | Desktop-first P0 |

## 23. Обязательные решения до старта

1. Принимаем ли изменение Product Charter: нативная размерная геометрия становится частью ArchiDom?
2. Это новый платный add-on или часть Studio Core?
3. Кто первый платящий wedge: дизайнеры квартир, коммерческие интерьеры или design-build?
4. Какой уровень нужен: layout tool или production documentation?
5. Build или licensed geometry kernel?
6. Где находится RU data plane?
7. Какие форматы обязательны кроме SVG/PDF/PNG/GLB?
8. Нужен ли IFC import/export, но не authoring?
9. Кто юридически отвечает за расчёты и дисклеймеры?
10. Как лицензируются модели, материалы и каталоги?
11. Нужна ли одновременная редактура в первом году?
12. Какие устройства являются поддерживаемыми?

## 24. Definition of Done для принятого KORA slice

- принят ADR о границе продукта;
- schema и contracts versioned;
- geometry invariants покрыты тестами;
- KORA fixture воспроизводится из исходных данных;
- второй внешний fixture проходит тем же pipeline;
- 2D/3D/elevation/quantities синхронны;
- exact revision publication работает;
- audit и access negative tests зелёные;
- GLB проходит validator;
- PDF/SVG не содержат внутренних путей или production filenames;
- performance budget выполнен;
- crash recovery проверен;
- source licenses зафиксированы;
- npm run lint, typecheck, test и build зелёные;
- создано руководство ручной проверки за 10 минут;
- ни один AI-процесс не утверждает геометрию.

## 25. Рекомендуемые ближайшие действия

1. Принять этот документ только как research baseline.
2. Рассмотреть [пакет двухнедельного KORA MVP](../layout-studio-mvp/README.md), включая Proposed ADR «Native Layout Studio boundary».
3. Зафиксировать KORA geometry evidence pack: размеры, стены, двери, колонна, высоты и equipment schedule.
4. Сделать двухнедельный geometry spike без production database.
5. Параллельно провести build/license market scan.
6. По итогам spike выбрать:
   - GO: KORA vertical slice;
   - PARTNER: лицензировать kernel;
   - NO-GO: оставить внешний adapter.
7. Не менять текущий authenticated pilot plan до отдельного ресурсного решения.

## 26. Официальные ссылки

- RemPlanner: https://remplanner.ru/
- PRO-возможности: https://remplanner.ru/planner/pro/
- FAQ: https://remplanner.ru/planner/support/faq/
- Пошаговая помощь: https://remplanner.ru/planner/support/
- PDF/печать: https://remplanner.ru/planner/print/

## 27. Итоговое решение v0.1

RemPlanner даёт качественную карту рынка и проверенную последовательность действий, но не предоставляет подходящую интеграционную основу для ArchiDom. Поэтому:

- **не встраиваем RemPlanner как наше ядро;**
- **не копируем его код или визуальный интерфейс;**
- **используем наблюдаемое поведение как clean-room functional benchmark;**
- **проектируем одну каноническую размерную модель ArchiDom;**
- **начинаем только с KORA vertical slice после ADR и geometry spike;**
- **наше отличие строим на Project Memory, exact revisions, provenance, impact и release, а не на повторении набора кнопок.**
