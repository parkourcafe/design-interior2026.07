# Исполняемое ТЗ для Codex — ArchiDom Layout Studio KORA MVP

Дата: 4 августа 2026 года

Статус: **ready after owner GO and Gate 0**

## 1. Outcome

За 10 рабочих дней создать в существующем repo внутренний, feature-flagged KORA Layout Studio MVP, который:

- загружает canonical fixture;
- редактирует разрешённые параметры;
- строит согласованные 2D и 3D;
- сохраняет local draft/checkpoints/versions;
- показывает version diff;
- экспортирует JSON/SVG/PNG/GLB/print summary;
- проходит acceptance suite и full repo checks.

Это timeboxed experiment, а не production CAD.

## 2. Обязательный baseline

До изменений Codex:

1. читает AGENTS.md;
2. читает весь пакет layout-studio-mvp;
3. читает Architecture v1 и ADR-0004;
4. выполняет git status внутри repo;
5. сохраняет inventory dirty files в report;
6. не изменяет и не откатывает чужие файлы;
7. проверяет текущие package versions и test commands;
8. подтверждает Gate 0;
9. перечисляет planned files;
10. создаёт implementation report.

Запрещены git reset --hard, checkout чужих файлов, destructive cleanup и неявная перезапись текущих изменений.

## 3. Hard constraints

- additive/new paths wherever possible;
- no Supabase migrations;
- no production access;
- no service role;
- no PII in fixtures;
- no proprietary RemPlanner assets/code/API;
- no .plan parsing;
- integer millimeters;
- pure domain independent of UI;
- one canonical model;
- published local versions immutable;
- AI absent;
- no scope expansion without owner decision;
- all UI strings routed through the accepted i18n approach if integration makes this practical; otherwise isolated MVP strings must be listed for later migration;
- dependency versions verified from primary documentation before install;
- package additions must be minimal and justified.

## 4. Work items

### LS-000 — Baseline and Gate 0

Outcome:

- trustworthy implementation baseline;
- confirmed KORA source table;
- no overlap with unrelated dirty work.

Acceptance:

- git status captured;
- current build/test baseline recorded;
- authoritative coordinates table exists;
- column/doors/equipment IDs frozen;
- dependency decision recorded;
- proposed file list approved.

Files:

~~~text
docs/product-intelligence/layout-studio-mvp/implementation/
  BASELINE_REPORT.md
  KORA_COORDINATE_FREEZE.md
  DEPENDENCY_DECISION.md
~~~

### LS-010 — Domain contract implementation

Depends on LS-000.

Outcome:

- TypeScript types and schema validation for contract v0.1.

Acceptance:

- no React/Next/Three imports;
- all dimensions integer;
- duplicate/missing references rejected;
- schema fixture tests pass;
- public index exposes only supported API.

Owned paths:

~~~text
lib/layout-studio/domain/**
tests/layout-studio/domain/**
~~~

### LS-011 — Commands, validation and canonical hash

Depends on LS-010.

Outcome:

- validated immutable command application;
- stateRevision;
- canonical serialization;
- semantic hash;
- diff.

Acceptance:

- stale revision rejected;
- invalid command leaves state unchanged;
- same semantic document gives same hash;
- timestamps/selection do not affect hash;
- diff reports exact fields.

Owned paths:

~~~text
lib/layout-studio/domain/commands*
lib/layout-studio/domain/apply-command*
lib/layout-studio/domain/validate*
lib/layout-studio/domain/canonical*
lib/layout-studio/domain/diff*
tests/layout-studio/domain/**
~~~

### LS-012 — Geometry derivation

Depends on LS-010.

Outcome:

- wall polygons;
- openings;
- room face/area;
- bounds;
- scene projection DTO.

Acceptance:

- zero wall rejected;
- simple room area exact;
- KORA contour derives without blocking issue after coordinate freeze;
- column is independent;
- opening stays within parent wall;
- derived data deterministic.

Owned paths:

~~~text
lib/layout-studio/domain/derive*
lib/layout-studio/domain/geometry/**
tests/layout-studio/domain/geometry/**
~~~

### LS-020 — 2D SVG editor

Depends on LS-010 contract; can start against simple fixture while LS-012 continues.

Outcome:

- pan/zoom/select;
- plan rendering;
- dimensions and labels;
- selected overlay;
- layer toggles.

Acceptance:

- KORA fixture fits viewport;
- all structural entities selectable;
- SVG uses derived projection;
- no duplicate geometry state;
- keyboard numeric inspector integration point exists.

Owned paths:

~~~text
components/layout-studio/layout-canvas-2d*
components/layout-studio/layout-toolbar*
components/layout-studio/layers*
components/layout-studio/styles*
tests/layout-studio/ui/2d*
~~~

### LS-021 — Inspector and editing

Depends on LS-011 and LS-020.

Outcome:

- numeric inspector;
- permitted drag;
- undo/redo;
- validation panel.

Acceptance:

- locked structural entity cannot move without unlock command not present in MVP;
- equipment can move in integer mm;
- invalid input rejected visibly;
- undo/redo preserves hash semantics;
- 2D selected object matches session selection.

Owned paths:

~~~text
components/layout-studio/object-inspector*
components/layout-studio/validation-panel*
lib/layout-studio/application/editor-session*
tests/layout-studio/application/**
~~~

### LS-030 — Three.js scene

Depends on LS-012.

Outcome:

- scene compiler and 3D view.

Acceptance:

- walls, openings, column, floor, ceiling and equipment appear;
- source stable ID retained;
- orbit/reset/hide ceiling work;
- no domain imports Three.js;
- adapter disposes GPU resources;
- fallback shown without WebGL.

Owned paths:

~~~text
lib/layout-studio/adapters/three/**
components/layout-studio/layout-view-3d*
tests/layout-studio/adapters/three/**
~~~

### LS-031 — Materials and lights

Depends on LS-030.

Outcome:

- KORA palette;
- task/decorative light distinction.

Acceptance:

- matte concrete visibly non-glossy;
- stainless differs from patina;
- neutral task light illuminates work zone;
- warm decorative source does not replace task light;
- assignments resolve by stable ID.

Owned paths:

~~~text
lib/layout-studio/adapters/three/material*
lib/layout-studio/adapters/three/light*
fixtures/layout-studio/materials*
tests/layout-studio/adapters/three/**
~~~

### LS-040 — KORA fixture

Depends on LS-000 and LS-010.

Outcome:

- authoritative fixture with no PII or absolute paths.

Acceptance:

- schema valid;
- column 250 × 250 mm;
- doors match coordinate freeze;
- equipment dimensions match evidence;
- central sink separate;
- one-sided/closed boundaries represented;
- all objects stable IDs;
- source refs sanitized.

Owned paths:

~~~text
fixtures/layout-studio/kora-liquid-station.v0.1.json
fixtures/layout-studio/README.md
tests/layout-studio/fixtures/**
~~~

### LS-050 — Local repository and versions

Depends on LS-011.

Outcome:

- autosave;
- checkpoints;
- immutable local versions;
- diff UI.

Acceptance:

- reload restores draft;
- stale save controlled;
- published version cannot update;
- Version A/B diff works;
- quota failure does not erase current session.

Owned paths:

~~~text
lib/layout-studio/application/version-service*
lib/layout-studio/adapters/local/**
components/layout-studio/versions-panel*
tests/layout-studio/application/version*
tests/layout-studio/adapters/local/**
~~~

### LS-060 — Export

Depends on LS-020, LS-030 and LS-050.

Outcome:

- JSON, SVG, PNG, GLB and print summary.

Acceptance:

- every artifact exact-version-bound;
- sidecar manifest;
- no private path/token/email;
- GLB uses meters;
- SVG/PNG omit selection;
- print includes hash and disclaimer;
- failed export controlled.

Owned paths:

~~~text
lib/layout-studio/application/export-service*
lib/layout-studio/adapters/svg/**
lib/layout-studio/adapters/three/glb*
components/layout-studio/export-panel*
app/app/layout-studio/**/print/**
tests/layout-studio/export/**
~~~

### LS-070 — Route and shell

Depends on LS-020, LS-030, LS-050.

Outcome:

- feature-flagged integrated demo.

Acceptance:

- disabled flag denies route or omits it from production;
- no auth regression;
- 2D/3D share session;
- loading/error/empty states;
- UI strings Russian;
- no change to public product promises.

Owned paths:

~~~text
app/app/layout-studio/**
components/layout-studio/layout-studio-shell*
lib/layout-studio/feature-flag*
tests/layout-studio/integration/**
~~~

### LS-080 — QA and handoff

Depends on all critical work items.

Outcome:

- reproducible demo;
- accepted or rejected spike.

Acceptance:

- critical acceptance tests pass;
- lint;
- typecheck;
- targeted tests;
- full tests;
- build;
- performance snapshot;
- browser smoke;
- GLB validation;
- final implementation report;
- GO/PARTNER/NO-GO recommendation.

Files:

~~~text
docs/product-intelligence/layout-studio-mvp/implementation/
  IMPLEMENTATION_REPORT.md
  VERIFICATION_REPORT.md
  PERFORMANCE_REPORT.md
  FINAL_GATE.md
~~~

## 5. Dependency graph

~~~mermaid
flowchart LR
  LS000 --> LS010
  LS010 --> LS011
  LS010 --> LS012
  LS010 --> LS020
  LS000 --> LS040
  LS010 --> LS040
  LS011 --> LS021
  LS020 --> LS021
  LS012 --> LS030
  LS030 --> LS031
  LS011 --> LS050
  LS020 --> LS060
  LS030 --> LS060
  LS050 --> LS060
  LS020 --> LS070
  LS030 --> LS070
  LS050 --> LS070
  LS040 --> LS070
  LS060 --> LS080
  LS070 --> LS080
  LS031 --> LS080
~~~

## 6. Параллельные lanes

После LS-010:

- Lane A: LS-011 + LS-012, pure domain/geometry;
- Lane B: LS-020 + LS-021, 2D/editor;
- Lane C: LS-030 + LS-031, 3D/materials;
- Lane D: LS-040 + LS-050 + LS-060 + LS-070 + LS-080, fixture/integration/QA.

Если используются несколько агентов:

- каждому назначить owned paths;
- агенты не одни в codebase;
- не откатывать изменения других;
- public contract меняет только Lane A owner;
- shared package/config меняет один integrator;
- не создавать несколько competing fixtures.

## 7. Daily gates

- Day 1: LS-000 + contract compile.
- Day 2: simple-room domain green.
- Day 3: KORA 2D recognizable and valid.
- Day 5: 2D→3D vertical slice; mid-spike GO/STOP.
- Day 7: materials + versions.
- Day 8: exports.
- Day 9: full integration and defect burn-down.
- Day 10: frozen demo and final gate.

## 8. Cut order при отставании

Удалять scope в таком порядке:

1. PNG export, если SVG остаётся;
2. textureRef, оставить material colors/PBR params;
3. fine-grained scene incremental updates, оставить full rebuild;
4. camera publication;
5. clearance visual styling, но не validation data;
6. decorative light editing.

Нельзя вырезать:

- canonical contract;
- integer mm;
- колонну/двери;
- one-model 2D/3D;
- validation;
- immutable version;
- JSON/SVG/GLB;
- tests/build.

## 9. Stop conditions

Codex останавливается и запрашивает решение, если:

- authoritative KORA dimensions противоречат друг другу;
- требуется изменить production migration;
- Three.js dependency несовместима с текущим React/Next;
- current dirty files перекрывают owned paths;
- build baseline уже красный и причина не относится к Layout Studio;
- невозможно обеспечить one-model architecture;
- Day 5 не показывает KORA в 3D;
- пользователь просит добавить full RemPlanner scope в текущий timebox.

## 10. Verification commands

Обязательные репозиторные команды:

~~~text
npm run lint
npm run typecheck
npm run test
npm run build
~~~

Плюс targeted tests для layout-studio. Конкретный script добавляется только если оправдан; иначе использовать существующий Vitest с path filter.

## 11. Delivery

Codex возвращает:

- ссылку на route;
- список изменённых файлов;
- краткое описание;
- test/build evidence;
- известные ограничения;
- demo steps;
- FINAL_GATE recommendation;
- отсутствие production migration;
- подтверждение, что unrelated dirty work preserved.

