# ArchiDom Layout Studio MVP — Requirements Traceability Matrix

Дата: 4 августа 2026 года

Статус: **frozen after Gate 0**

Матрица связывает продуктовые требования, реализацию, тесты и evidence. Функция без строки в матрице не входит в MVP.

| Requirement | Требование | Work items | Acceptance | Evidence |
|---|---|---|---|---|
| LS-REQ-001 | Одна canonical model управляет 2D и 3D | LS-010, LS-012, LS-020, LS-030 | LS-AT-040–042, 084 | Domain dependency report, integration test |
| LS-REQ-002 | Все canonical размеры integer mm | LS-010, LS-011 | LS-AT-003, 006 | Schema/unit tests |
| LS-REQ-003 | KORA contour соответствует frozen plan | LS-040 | LS-AT-010, 020 | Coordinate freeze, SVG golden |
| LS-REQ-004 | Колонна отдельная 250 × 250 мм | LS-012, LS-040 | LS-AT-011, 012, 031 | Fixture inspection, 3D screenshot |
| LS-REQ-005 | Двери сохранены и привязаны к стенам | LS-012, LS-040 | LS-AT-013, 018, 032 | Fixture + opening tests |
| LS-REQ-006 | Центральная мойка отдельна | LS-040 | LS-AT-015 | Fixture/object schedule |
| LS-REQ-007 | Rear equipment соответствует ведомости | LS-040 | LS-AT-014 | Equipment freeze |
| LS-REQ-008 | 2D pan/zoom/select/dimensions | LS-020 | LS-AT-020–026 | Browser smoke, SVG golden |
| LS-REQ-009 | Numeric edit и undo/redo | LS-011, LS-021 | LS-AT-030–037 | Application tests |
| LS-REQ-010 | Invalid edit не портит состояние | LS-011, LS-021 | LS-AT-017, 018, 033, 036 | Validation tests |
| LS-REQ-011 | Производная читаемая 3D-сцена | LS-030 | LS-AT-040–046 | Browser smoke, performance |
| LS-REQ-012 | KORA материалы и два типа света | LS-031 | LS-AT-050–054 | Visual acceptance |
| LS-REQ-013 | Draft переживает reload | LS-050 | LS-AT-060, 086 | Local adapter test |
| LS-REQ-014 | Published versions immutable | LS-011, LS-050 | LS-AT-062–065, 077 | Version tests |
| LS-REQ-015 | Semantic hash детерминирован | LS-011, LS-050 | LS-AT-068 | Canonical golden |
| LS-REQ-016 | A/B field-level diff | LS-011, LS-050 | LS-AT-066 | Diff test + demo |
| LS-REQ-017 | JSON/SVG/GLB exact-version exports | LS-060 | LS-AT-070, 071, 073, 077 | Export pack |
| LS-REQ-018 | Print summary с hash/disclaimer | LS-060 | LS-AT-074 | Print snapshot |
| LS-REQ-019 | Export privacy | LS-060, LS-080 | LS-AT-075, 076 | Privacy scan |
| LS-REQ-020 | Feature-flagged internal delivery | LS-070 | LS-AT-080, 081 | Route test |
| LS-REQ-021 | Нет production migration | LS-000, LS-070 | LS-AT-082 | Git diff |
| LS-REQ-022 | Existing ArchiDom workflows не ломаются | LS-070, LS-080 | LS-AT-083, 085 | Full regression |
| LS-REQ-023 | KORA interaction укладывается в performance budget | LS-020, LS-030, LS-080 | LS-AT-090–094 | Performance report |
| LS-REQ-024 | Второй non-KORA fixture предотвращает hardcode | LS-010, LS-012 | LS-AT-001 | simple-room golden |
| LS-REQ-025 | Demo flow проходит менее чем за 10 минут | LS-080 | Manual demo acceptance | Demo log |

## 1. Critical path

Критические требования:

- LS-REQ-001–007;
- LS-REQ-009–011;
- LS-REQ-013–022;
- LS-REQ-024–025.

Они не могут быть waived без Day 10 owner decision.

## 2. Change rule

Для нового требования необходимо одновременно:

1. присвоить LS-REQ ID;
2. указать заменяемый scope item;
3. назначить work item;
4. добавить acceptance test;
5. определить evidence;
6. обновить timebox decision.

Если один элемент отсутствует, требование автоматически относится к post-spike backlog.

