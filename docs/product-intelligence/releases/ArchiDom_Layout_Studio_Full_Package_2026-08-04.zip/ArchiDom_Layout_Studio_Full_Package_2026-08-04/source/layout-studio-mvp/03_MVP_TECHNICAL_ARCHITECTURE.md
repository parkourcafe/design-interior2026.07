# ArchiDom Layout Studio — техническая архитектура двухнедельного MVP

Дата: 4 августа 2026 года

Статус: **proposed implementation contract**

## 1. Архитектурная цель

Проверить минимальную вертикаль:

~~~text
canonical layout document
  → validated command
  → derived room/surfaces
  → 2D SVG
  → 3D scene
  → immutable local version
  → export artifacts
~~~

В MVP запрещено создавать независимые 2D state и 3D state.

## 2. Контекст

~~~mermaid
flowchart LR
  User["KORA editor"] --> Route["Feature-flagged Layout Studio route"]
  Route --> Session["Editor Session"]
  Session --> Commands["Command Engine"]
  Commands --> Domain["Pure Layout Domain"]
  Domain --> Derive["Geometry Derivation"]
  Derive --> SVG["2D SVG Adapter"]
  Derive --> Three["Three.js Scene Adapter"]
  Session --> Local["Local Repository Adapter"]
  Local --> Versions["Immutable Local Versions"]
  Versions --> Export["JSON / SVG / PNG / GLB / Print"]
  Versions -. future port .-> Memory["Project Intelligence Memory"]
~~~

## 3. Слои

### 3.1. Domain

Владеет:

- entities;
- integer millimeter values;
- validation;
- commands;
- stable IDs;
- semantic serialization;
- diff;
- geometry invariants.

Не импортирует:

- React;
- Next.js;
- DOM;
- SVG;
- Three.js;
- Supabase;
- browser storage.

### 3.2. Application

Владеет:

- session state;
- command order;
- undo/redo;
- expected state revision;
- checkpoint;
- publish local version;
- export orchestration;
- ports.

### 3.3. Adapters

- SVG renderer;
- Three.js scene compiler;
- local repository;
- hash;
- PNG capture;
- GLB exporter;
- print view.

### 3.4. Delivery/UI

- route;
- toolbar;
- 2D/3D tabs;
- inspector;
- validation panel;
- versions panel;
- export panel.

UI не содержит geometry rules.

## 4. Рекомендуемая структура файлов

~~~text
lib/layout-studio/
  domain/
    types.ts
    ids.ts
    units.ts
    invariants.ts
    validate.ts
    commands.ts
    apply-command.ts
    derive.ts
    diff.ts
    canonical.ts
    index.ts
  application/
    ports.ts
    editor-session.ts
    version-service.ts
    export-service.ts
  adapters/
    local/
      local-layout-repository.ts
    svg/
      svg-projection.ts
    three/
      scene-compiler.ts
      glb-export.ts
components/layout-studio/
  layout-studio-shell.tsx
  layout-toolbar.tsx
  layout-canvas-2d.tsx
  layout-view-3d.tsx
  object-inspector.tsx
  validation-panel.tsx
  versions-panel.tsx
  export-panel.tsx
app/app/layout-studio/kora-liquid-station/
  page.tsx
fixtures/layout-studio/
  kora-liquid-station.v0.1.json
  simple-room.v0.1.json
tests/layout-studio/
  domain/**
  application/**
  integration/**
~~~

Финальные имена могут адаптироваться к фактическому repo, но dependency direction не меняется.

## 5. Runtime state

EditorSession:

~~~text
document
stateRevision
selection
activeView
camera
undoStack
redoStack
validation
dirty
lastSavedAt
~~~

Selection и camera не входят в semantic geometry hash, если не публикуются как именованный view.

## 6. Command flow

~~~mermaid
sequenceDiagram
  participant UI
  participant Session
  participant Domain
  participant Repository
  participant Views

  UI->>Session: dispatch(command, expectedRevision)
  Session->>Domain: validate + apply
  Domain-->>Session: nextDocument + issues
  Session->>Session: push undo entry
  Session->>Views: invalidate affected projections
  Session->>Repository: debounced save draft
  Views-->>UI: render 2D and 3D from nextDocument
~~~

Невалидная команда возвращает controlled error и не меняет последнее валидное состояние.

## 7. Геометрия MVP

### 7.1. Primitive model

- Vec2Mm: x, y integer;
- Node: stable id + Vec2Mm;
- Wall: startNodeId, endNodeId, thicknessMm, heightMm;
- Opening: parentWallId, offsetMm, widthMm, heightMm, sillMm;
- Column: xMm, yMm, widthMm, depthMm, heightMm;
- Equipment: xMm, yMm, zMm, widthMm, depthMm, heightMm, rotationDeg;
- ClearanceZone: polygon, severity;
- MaterialAssignment: targetId, surfaceRole, materialId.

### 7.2. Room

Для MVP допустим:

- один ожидаемый замкнутый контур;
- straight segment graph;
- отсутствие self-intersection;
- simple face extraction;
- площадь в mm² с display в m².

Если контур не замкнут, 3D стены всё равно могут строиться, но room area и publication получают blocking issue.

### 7.3. Wall mesh

MVP wall mesh:

1. построить rectangle вокруг осевой линии;
2. extrude до heightMm;
3. вырезать или сегментировать openings;
4. назначить interior/exterior/top material roles;
5. сохранить stable source ID в mesh.userData.

Сложные boolean operations можно заменить сегментацией стены вокруг прямоугольного opening.

## 8. 2D renderer

Для timebox выбран React SVG:

- viewBox в canonical coordinates;
- one SVG group per layer;
- wall polygons;
- opening symbols;
- equipment rectangles;
- column rectangle;
- dimension lines;
- labels;
- hit targets;
- selected overlay;
- pan/zoom transform.

Преимущества:

- нет обязательной новой 2D graphics dependency;
- простой SVG export;
- прозрачное visual testing;
- достаточно для KORA scale.

Ограничение: если KORA benchmark показывает frame drops или сложный hit testing, post-spike решение рассматривает PixiJS/Canvas/WebGL.

## 9. 3D adapter

Three.js получает immutable projection DTO:

~~~text
SceneProjection
  walls[]
  openings[]
  columns[]
  equipment[]
  planes[]
  lights[]
  materials[]
~~~

Adapter:

- не меняет domain;
- пересобирает только invalidated object groups, если это успевает войти;
- поддерживает OrbitControls;
- показывает box geometry для custom equipment;
- экспортирует GLB;
- удаляет geometries/materials при unmount;
- восстанавливается после WebGL context loss либо показывает controlled fallback.

## 10. Материалы

MaterialDefinition MVP:

- id;
- labelRu;
- baseColor;
- roughness;
- metalness;
- emissive;
- emissiveIntensity;
- textureRef optional;
- license/provenance.

Текстуры не обязательны для Gate 1. Цвет, roughness и metalness достаточно для проверки design direction.

## 11. Persistence

LayoutRepository port:

~~~text
loadDraft(documentId)
saveDraft(document, expectedStateRevision)
listVersions(documentId)
publishVersion(document, metadata)
loadVersion(versionId)
~~~

Local adapter:

- draft в localStorage или IndexedDB;
- immutable versions по unique key;
- schema version;
- canonical JSON;
- SHA-256 через Web Crypto;
- controlled quota error;
- reset только по явной команде.

Выбор localStorage против IndexedDB принимается Day 1 по размеру fixture. Если canonical fixture превышает 1 MB или содержит binary assets, использовать IndexedDB.

## 12. Version semantics

- stateRevision монотонен внутри draft;
- checkpoint сохраняет recoverable draft snapshot;
- publish создаёт immutable version ID;
- published content canonicalized;
- semantic hash не включает timestamps/UI selection/camera, если camera не является published view;
- изменение после publish создаёт новый draft lineage;
- rollback создаёт новую draft, не изменяет старую version.

## 13. Export

### JSON

Canonical document + version envelope + checksum.

### SVG

Проекция exact version, без UI selection и private paths.

### PNG

Raster exact SVG/Canvas at configured pixel size.

### GLB

Exact scene, stable source IDs in extras where supported, materials and scale in meters per glTF convention.

### Print

HTML print page:

- project;
- variant;
- version;
- hash;
- units;
- warnings;
- 2D preview;
- object schedule;
- disclaimer.

## 14. Feature flag

Рекомендуемый server-read flag:

~~~text
LAYOUT_STUDIO_KORA_PREVIEW=true
~~~

Flag не передаёт authorization. Route дополнительно использует существующую authenticated shell. Если безопасная auth integration требует изменения общего runtime, Day 1 допускает dev-only route, недоступный production build.

## 15. Ошибки

Минимальные stable codes:

- INVALID_DOCUMENT;
- INVALID_UNITS;
- WALL_ZERO_LENGTH;
- WALL_SELF_INTERSECTION;
- OPENING_PARENT_MISSING;
- OPENING_OUT_OF_BOUNDS;
- COLUMN_INVALID_SIZE;
- OBJECT_COLLISION;
- CLEARANCE_VIOLATION;
- STATE_STALE;
- VERSION_IMMUTABLE;
- STORAGE_QUOTA;
- EXPORT_FAILED;
- WEBGL_UNAVAILABLE.

## 16. Нефункциональные цели

- pan/zoom/drag p95 визуально плавные на KORA fixture;
- simple command менее 100 мс;
- load fixture менее 2 с после JS load;
- 3D first useful frame менее 5 с;
- deterministic hash;
- no production secrets;
- no absolute file paths in exports;
- keyboard numeric input;
- no data loss after successful local save;
- full app build remains green.

## 17. Будущие extension points

- Canvas/WebGL 2D renderer;
- server repository;
- RLS;
- multiple floors/variants;
- wall elevations;
- MEP;
- quantities;
- catalogs;
- CRDT/presence;
- AI render adapter.

Ни один future extension не должен требовать смены canonical geometry IDs.

