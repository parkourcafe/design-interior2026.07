# ArchiDom Layout Studio — план выполнения за 10 рабочих дней

Дата: 4 августа 2026 года

Статус: **proposed schedule**

## 1. Правило timebox

Каждый день заканчивается работающим интегрированным состоянием. Незавершённая экспериментальная ветка не может заменять последний зелёный vertical slice.

При задержке scope сокращается по правилам Codex Execution Spec. Срок не продлевается автоматически.

## 2. Роли

| Lane | Ответственность |
|---|---|
| A — Domain/Geometry | Контракт, commands, validation, derivation, hash, diff |
| B — 2D/Editor | SVG, selection, inspector, undo/redo |
| C — 3D/Assets | Three.js, scene, materials, lights, GLB |
| D — Integration/QA | KORA fixture, local repository, route, export, tests, reports |

Один человек может вести несколько lanes. Если работают агенты, shared contracts изменяет только Lane A owner, package/config — только integrator.

## День 1 — Gate 0 и skeleton

Цель:

- доказать, что задача имеет стабильный вход и изолированное место в repo.

Работы:

- прочитать contract pack;
- зафиксировать dirty worktree;
- проверить baseline lint/typecheck/test/build;
- создать KORA coordinate freeze;
- решить dependency Three.js;
- создать новые module directories;
- реализовать core types;
- подключить JSON schema validation;
- создать simple-room fixture.

Выход:

- BASELINE_REPORT;
- KORA_COORDINATE_FREEZE;
- DEPENDENCY_DECISION;
- simple fixture schema green;
- empty feature-flagged route либо isolated story/demo harness.

Gate:

- если нет подтверждённых координат, structural KORA fixture не кодируется;
- можно продолжить только pure domain на simple-room.

## День 2 — Commands и geometry baseline

Цель:

- получить детерминированный документ, который можно безопасно менять.

Работы:

- stable IDs;
- invariants;
- command envelope;
- apply command;
- stateRevision;
- wall polygons;
- opening bounds;
- simple room face and area;
- canonical serialization;
- hash tests.

Выход:

- domain public API;
- green unit/property tests;
- simple-room derived projection.

Gate:

- domain не импортирует UI/runtime libraries;
- hash воспроизводим.

## День 3 — KORA 2D

Цель:

- увидеть узнаваемый точный KORA plan.

Работы:

- заполнить frozen KORA fixture;
- SVG projection;
- pan/zoom/fit;
- walls/openings/column/equipment;
- dimensions/labels;
- layer toggles;
- validation list.

Выход:

- KORA план в browser;
- колонна 250 × 250;
- двери и rear equipment line;
- screenshot/golden.

Gate:

- архитектурные ограничения не подменены декоративной картинкой;
- нет blocking geometry issues.

## День 4 — Inspector и interaction

Цель:

- доказать, что это редактор, а не viewer.

Работы:

- selection;
- numeric inspector;
- permitted equipment movement;
- locked structural objects;
- command validation;
- undo/redo;
- clearance zones;
- selected overlay.

Выход:

- пользователь меняет equipment X/Y/rotation/dimensions в допустимых границах;
- колонна и двери не двигаются обычным drag;
- invalid edit безопасно отклоняется.

Gate:

- все изменения идут через command engine.

## День 5 — Первый сквозной 3D и mid-spike gate

Цель:

- завершить главную техническую гипотезу one model → 2D + 3D.

Работы:

- Three.js setup;
- wall extrusion;
- openings;
- floor/ceiling;
- column;
- equipment boxes;
- orbit/reset;
- hide ceiling;
- stable ID mapping.

Выход:

- KORA 3D, построенный из того же document;
- object selection mapping;
- first performance snapshot.

Mid-spike decision:

- GO — продолжать;
- REDUCE — убрать secondary features;
- STOP — сохранить evidence и не тратить вторую неделю.

STOP, если KORA 3D требует отдельного ручного scene state.

## День 6 — Материалы, свет и visual legibility

Цель:

- сделать сцену пригодной для обсуждения дизайна, не уходя в рендер.

Работы:

- KORA material palette;
- assignments;
- neutral task lighting;
- warm decorative lighting;
- selected highlight;
- matte versus metal distinction;
- WebGL fallback.

Выход:

- читаемая неглянцевая сцена;
- рабочая зона освещена;
- материал меняется через canonical assignment.

Gate:

- материал и light ID сохраняются в version;
- renderer не меняет domain.

## День 7 — Persistence и versions

Цель:

- исключить потерю изменений и передачу «не той картинки».

Работы:

- repository port;
- local adapter;
- autosave;
- checkpoint;
- immutable publish;
- versions list;
- restore as new draft;
- diff engine/UI;
- storage error handling.

Выход:

- Version A и Version B;
- reload recovery;
- field-level diff;
- semantic hashes.

Gate:

- published Version A не меняется после редактирования Version B.

## День 8 — Exports

Цель:

- получить переносимые artifacts.

Работы:

- canonical JSON;
- clean SVG;
- PNG, если не мешает critical path;
- GLB;
- sidecar manifest;
- print summary;
- privacy scrub check;
- GLB unit conversion.

Выход:

- export pack exact Version B.

Gate:

- нет absolute paths, email, tokens;
- GLB открывается внешним viewer/validator;
- SVG не содержит UI overlays.

## День 9 — Integration и defect burn-down

Цель:

- превратить части в воспроизводимый demo flow.

Работы:

- route/shell/feature flag;
- loading/error states;
- keyboard pass;
- integration tests;
- visual goldens;
- full repo regression;
- fix critical defects;
- prepare demo fixture reset.

Выход:

- один URL/route;
- один 10-minute flow;
- acceptance matrix with evidence.

Gate:

- все P0 tests pass;
- no unrelated regression.

## День 10 — Freeze, verification и решение

Цель:

- зафиксировать результат, а не добавлять функции.

Работы:

- запретить feature additions;
- выполнить full verification;
- browser smoke;
- export smoke;
- performance measurement;
- documentation;
- known limitations;
- video/screenshots при необходимости;
- GO/PARTNER/NO-GO recommendation.

Выход:

- IMPLEMENTATION_REPORT;
- VERIFICATION_REPORT;
- PERFORMANCE_REPORT;
- FINAL_GATE;
- reproducible demo instructions.

## 3. Ежедневный ритм

Начало дня:

1. проверить status;
2. прочитать предыдущий handoff;
3. подтвердить owned paths;
4. запустить targeted baseline.

Перед интеграцией:

1. unit tests;
2. typecheck затронутого scope;
3. fixture validation;
4. review dependency direction.

Конец дня:

1. обновить status;
2. перечислить changed files;
3. сохранить evidence;
4. зафиксировать blocker/cut;
5. оставить зелёный demo path.

## 4. Контроль загрузки

| День | Обязательный результат | Дополнительный |
|---:|---|---|
| 1 | Contract + fixture skeleton | route shell |
| 2 | Domain + hash | property tests |
| 3 | KORA 2D | decorative overlays |
| 4 | Inspector + undo | clearance styling |
| 5 | KORA 3D | incremental scene update |
| 6 | Materials + task light | texture |
| 7 | Versions + diff | named camera |
| 8 | JSON/SVG/GLB | PNG |
| 9 | Integrated acceptance | UI polish |
| 10 | Verification + decision | presentation media |

## 5. Защита от scope creep

Любая новая идея получает один из статусов:

- required to pass P0;
- replace existing MVP item;
- post-spike backlog;
- rejected.

Фраза «это маленькая функция» не является основанием добавить её без удаления другой задачи.

