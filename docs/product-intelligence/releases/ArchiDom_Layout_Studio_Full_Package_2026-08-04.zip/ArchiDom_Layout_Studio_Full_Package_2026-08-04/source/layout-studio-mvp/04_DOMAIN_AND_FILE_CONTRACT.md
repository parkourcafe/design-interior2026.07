# ArchiDom Layout Studio — Domain and File Contract v0.1

Дата: 4 августа 2026 года

Статус: **frozen for two-week MVP after Gate 0**

Машиночитаемая схема: layout-document-v0.1.schema.json.

## 1. Назначение

Контракт определяет канонический документ, команды, версии, diff и export envelope. Он является границей между:

- domain;
- 2D renderer;
- 3D renderer;
- local persistence;
- fixtures;
- tests;
- будущим Project Memory adapter.

Renderer не имеет права вводить поля геометрии, которых нет в этом контракте.

## 2. Версия и единицы

- contractVersion: archidom.layout-document/0.1;
- canonicalUnits: mm;
- все координаты и линейные размеры — integer;
- углы MVP: 0, 90, 180, 270 degrees;
- площадь вычисляется в mm²;
- display m² округляется только в UI;
- glTF adapter конвертирует millimeters в meters на границе.

## 3. Stable ID

Формат:

~~~text
kind.project-local-key
~~~

Примеры:

~~~text
node.kora.nw
wall.kora.north
opening.kora.rear-door-left
column.kora.center
object.kora.espresso
material.kora.matte-concrete
light.kora.task-01
~~~

Правила:

- ID не содержит PII и исходных filenames;
- ID не меняется при перемещении;
- новый логический объект получает новый ID;
- delete + recreate не переиспользует published ID;
- ID уникален внутри document;
- display label может меняться независимо.

## 4. Root document

Обязательные поля:

| Поле | Смысл |
|---|---|
| contractVersion | Версия схемы |
| documentId | Stable LayoutDocument ID |
| projectId | Stable Project ID |
| name | Пользовательское имя |
| canonicalUnits | Всегда mm в v0.1 |
| stateRevision | Монотонная draft revision |
| floor | Единственный Floor MVP |
| variant | Единственный Variant MVP |
| nodes | Вершины стен |
| walls | Стены |
| openings | Проёмы |
| columns | Колонны |
| objects | Стойки, мойка и оборудование |
| clearanceZones | Технологические зоны |
| materials | Палитра |
| materialAssignments | Назначения поверхностям |
| lights | Свет |
| metadata | Provenance и предупреждения |

Derived rooms, wall surfaces и 3D meshes не записываются в canonical document.

## 5. Entities

### 5.1. Node

~~~text
id
xMm
yMm
locked
~~~

### 5.2. Wall

~~~text
id
startNodeId
endNodeId
thicknessMm
heightMm
kind: existing | partition
locked
label
~~~

### 5.3. Opening

~~~text
id
parentWallId
kind: door | free_opening | window
offsetMm
widthMm
heightMm
sillMm
handing optional
locked
label
~~~

offsetMm измеряется вдоль wall axis от start node до левого края opening.

### 5.4. Column

~~~text
id
xMm
yMm
widthMm
depthMm
baseZMm
heightMm
rotationDeg
locked
label
~~~

xMm/yMm — центр column footprint.

### 5.5. Placed Object

~~~text
id
kind: counter | sink | equipment | decor | service
catalogKey optional
xMm
yMm
zMm
widthMm
depthMm
heightMm
rotationDeg
locked
label
notes optional
~~~

xMm/yMm — центр footprint. zMm — отметка низа.

### 5.6. Clearance Zone

~~~text
id
label
polygon[]
severity: info | warning | blocking
relatedObjectIds[]
~~~

Clearance zone видна в 2D по toggle и не экспортируется как физическая 3D geometry.

### 5.7. Material

~~~text
id
labelRu
baseColor
roughness
metalness
emissive
emissiveIntensity
textureRef optional
provenance
~~~

### 5.8. Assignment

~~~text
id
targetId
surfaceRole
materialId
~~~

surfaceRole MVP:

- all;
- front;
- back;
- side;
- top;
- floor;
- ceiling;
- interior;
- exterior.

### 5.9. Light

~~~text
id
kind: ambient | directional | point | linear_proxy
xMm
yMm
zMm
color
intensity
targetId optional
label
~~~

## 6. Commands

Минимальный envelope:

~~~text
commandId
idempotencyKey
documentId
expectedStateRevision
type
payload
reasonCode
reason
~~~

MVP command types:

- MOVE_NODE;
- UPDATE_WALL;
- UPDATE_OPENING;
- UPDATE_COLUMN;
- MOVE_OBJECT;
- UPDATE_OBJECT;
- ASSIGN_MATERIAL;
- UPDATE_LIGHT;
- RESTORE_CHECKPOINT.

Команды создания/удаления допускаются только для non-locked decor/equipment в MVP. Structural walls, doors и central column KORA locked по умолчанию.

## 7. Validation

Issue:

~~~text
code
severity: info | warning | blocking
entityIds[]
messageKey
details
~~~

Blocking:

- invalid schema;
- zero wall;
- missing node;
- missing opening parent;
- opening outside wall;
- invalid column dimensions;
- self-intersecting room contour;
- duplicate stable ID;
- non-integer canonical dimension;
- equipment outside declared project bounds, если bounds подтверждены;
- attempt to publish invalid document.

Warning:

- clearance overlap;
- equipment collision;
- unassigned material;
- room contour not detected;
- unsupported 3D detail reduced to box.

## 8. Derived projection

deriveLayout(document) возвращает:

~~~text
DerivedLayout
  valid
  issues[]
  wallPolygons[]
  roomFaces[]
  roomAreaMm2 optional
  surfaceRefs[]
  sceneProjection
  bounds
~~~

DerivedLayout не сохраняется как источник истины. Cache допустим только с ключом semantic content hash.

## 9. Canonical serialization

До hash:

1. удалить UI/session fields;
2. нормализовать object keys;
3. сортировать entities по stable ID;
4. сортировать assignments/lights/zones по stable ID;
5. сохранить array order только там, где он семантичен, например polygon;
6. не включать timestamps;
7. сериализовать UTF-8;
8. вычислить SHA-256.

stateRevision не входит в semantic content hash. Две revisions с одинаковой геометрией дают одинаковый semantic hash.

## 10. Version envelope

~~~text
contractVersion: archidom.layout-version/0.1
versionId
documentId
parentVersionId optional
semanticHash
content
authorType: human
reasonCode
reason
createdAt
warnings[]
~~~

Local adapter может использовать synthetic human actor label без email/PII.

## 11. Diff contract

~~~text
LayoutDiff
  fromVersionId
  toVersionId
  addedEntityIds[]
  removedEntityIds[]
  changed[]

ChangedEntity
  entityId
  entityType
  fields[]

ChangedField
  path
  before
  after
~~~

Diff вычисляется по canonical content, не по rendered SVG или mesh.

## 12. Export envelope

Каждый export имеет sidecar manifest:

~~~text
contractVersion: archidom.layout-export/0.1
artifactId
format
documentId
versionId
semanticHash
generatedAt
generatorVersion
artifactChecksum
warnings[]
~~~

В artifact и manifest запрещены:

- абсолютные пути;
- production filenames;
- email;
- auth token;
- signed URL;
- RemPlanner private links;
- browser local storage keys.

## 13. Contract changes

До окончания spike:

- additive optional field требует schema update + fixture + tests;
- изменение смысла существующего поля запрещено;
- изменение units запрещено;
- смена ID semantics запрещена;
- renderer-specific property в domain запрещено;
- schema version bump обязателен при breaking change.

## 14. Golden fixtures

Обязательные:

- simple-room.v0.1.json;
- kora-liquid-station.v0.1.json.

Для каждой фиксируются:

- schema validation;
- semantic hash;
- derived bounds;
- wall count;
- opening count;
- column count;
- object count;
- expected blocking/warnings;
- SVG golden;
- scene object count.

