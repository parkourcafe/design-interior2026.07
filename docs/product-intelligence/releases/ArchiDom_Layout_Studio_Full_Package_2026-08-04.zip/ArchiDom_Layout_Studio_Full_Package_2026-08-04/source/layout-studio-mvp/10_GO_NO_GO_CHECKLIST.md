# ArchiDom Layout Studio — GO/NO-GO checklist

Дата: 4 августа 2026 года

## A. Owner GO до старта

- [ ] Я подтверждаю: цель — KORA MVP, не полный RemPlanner.
- [ ] Я подтверждаю timebox 10 рабочих дней.
- [ ] Я принимаю desktop-first internal preview.
- [ ] Я принимаю один этаж и один вариант.
- [ ] Я принимаю отсутствие production database.
- [ ] Я принимаю отсутствие MEP, смет и AI.
- [ ] Я разрешаю локальные версии и открытые exports.
- [ ] Я понимаю, что Proposed ADR не меняет публичный Charter.
- [ ] Я согласна на Day 5 STOP, если one-model 2D/3D не работает.

Owner:

Date:

Decision: GO / NO-GO

## B. Technical Gate 0

- [ ] Dirty worktree inventory сохранён.
- [ ] Unrelated files не входят в ownership.
- [ ] Baseline commands записаны.
- [ ] KORA coordinate table подтверждена.
- [ ] Column X/Y/250×250/height подтверждены.
- [ ] Doors confirmed.
- [ ] Equipment schedule confirmed.
- [ ] EQ-04 height conflict resolved.
- [ ] Sink coordinates confirmed.
- [ ] 3000 mm constraint anchored.
- [ ] Three.js dependency decision complete.
- [ ] Feature flag strategy complete.

Decision: PASS / BLOCKED

## C. Day 5 gate

- [ ] KORA 2D узнаваем и размерно корректен.
- [ ] Structural entities parametric.
- [ ] Column independent.
- [ ] Doors attached.
- [ ] KORA 3D generated from same document.
- [ ] One edited object updates both views.
- [ ] No production dependency.
- [ ] Performance acceptable.

Decision:

- [ ] GO;
- [ ] REDUCE;
- [ ] STOP.

Required cuts/reasons:

## D. Day 10 final gate

### Product

- [ ] Demo solves KORA handoff problem.
- [ ] Owner completes flow in under 10 minutes.
- [ ] Limitations are understood.

### Architecture

- [ ] Pure domain.
- [ ] One canonical model.
- [ ] Integer millimeters.
- [ ] Stable IDs.
- [ ] Immutable versions.
- [ ] Open exports.

### Quality

- [ ] 100% P0 acceptance PASS.
- [ ] Lint PASS.
- [ ] Typecheck PASS.
- [ ] Tests PASS.
- [ ] Build PASS.
- [ ] Browser smoke PASS.
- [ ] GLB validation PASS.
- [ ] Privacy scan PASS.

### Decision

- [ ] GO — строить beta;
- [ ] PARTNER — искать/licence geometry SDK;
- [ ] NO-GO — оставить RemPlanner/external workflow;
- [ ] EXTEND SPIKE — только с новым budget/scope decision.

Owner:

Date:

Rationale:

