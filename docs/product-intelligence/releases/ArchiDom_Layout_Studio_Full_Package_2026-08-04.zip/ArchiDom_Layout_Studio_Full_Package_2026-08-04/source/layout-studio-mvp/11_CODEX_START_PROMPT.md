# Стартовый prompt для Codex — Layout Studio KORA MVP

Скопируйте текст ниже в новую задачу Codex после Owner GO.

---

Ты работаешь в репозитории ArchiDom. Твоя задача — выполнить timeboxed KORA Layout Studio MVP за 10 рабочих дней по frozen contract. Это внутренний experiment, а не production CAD и не полный аналог RemPlanner.

Сначала полностью прочитай:

1. root и repo AGENTS.md;
2. docs/product-intelligence/ArchiDom_Russia_Product_Charter_v0.4_2026-07-18.md;
3. docs/product-intelligence/architecture-v1.md;
4. docs/product-intelligence/adr/0004-one-archidom-four-workspaces.md;
5. docs/product-intelligence/research/ARCHIDOM_LAYOUT_STUDIO_CLEAN_ROOM_ARCHITECTURE_v0.1_2026-08-04.md;
6. все файлы docs/product-intelligence/layout-studio-mvp/ в порядке README;
7. layout-document-v0.1.schema.json.

Целевой outcome:

- feature-flagged internal route;
- KORA one-floor/one-variant fixture;
- canonical integer-mm domain;
- walls, openings, 250×250 column, counter, central sink and rear equipment;
- 2D SVG editor with selection/numeric inspector/undo;
- derived Three.js 3D;
- KORA materials and task/decorative lights;
- local draft/checkpoint/immutable versions;
- A/B diff;
- JSON/SVG/PNG if time permits/GLB/print exports;
- full acceptance and repo verification.

До кода выполни LS-000:

1. Покажи git status и inventory всех dirty files.
2. Не изменяй, не откатывай и не удаляй чужие изменения.
3. Запусти baseline lint/typecheck/test/build или зафиксируй pre-existing blocker.
4. Проверь KORA Evidence Manifest.
5. Создай KORA_COORDINATE_FREEZE.md.
6. Не придумывай отсутствующие размеры.
7. Проверь совместимую версию Three.js по официальной документации.
8. Перечисли planned files и ownership.
9. Обнови план по LS IDs.
10. Остановись, если Gate 0 BLOCKED.

Hard constraints:

- no Supabase migrations;
- no production access/credentials;
- no service role;
- no hidden RemPlanner API or .plan reverse engineering;
- no AI;
- no full MEP/smeta/catalog;
- no separate 3D geometry state;
- no floats as canonical dimensions;
- no mutable published version;
- no PII/absolute paths/private links in fixture/export;
- pure domain does not import React/Next/Three/Supabase;
- use apply_patch for edits;
- preserve current dirty worktree;
- dependency/config files have one owner;
- when multiple agents are used, assign disjoint owned paths and tell each agent they are not alone in the codebase and must accommodate others.

Implementation order:

LS-000 → LS-010 → parallel LS-011/LS-012/LS-020/LS-040 → LS-021/LS-030/LS-050 → LS-031/LS-060/LS-070 → LS-080.

Day 5 mandatory gate:

- exact KORA 2D;
- generated KORA 3D;
- one edited object updates both;
- column and doors correct;
- no manual duplicate scene.

If Day 5 fails, stop and write evidence-based STOP recommendation. Do not mask failure with a prerendered image.

Testing:

- schema tests;
- unit/property geometry tests;
- application/version tests;
- export tests;
- KORA and simple-room golden fixtures;
- acceptance matrix;
- npm run lint;
- npm run typecheck;
- npm run test;
- npm run build.

Every exported artifact must bind exact version + semantic hash and contain no private paths, email, token or production filename.

At the end create:

- docs/product-intelligence/layout-studio-mvp/implementation/IMPLEMENTATION_REPORT.md;
- VERIFICATION_REPORT.md;
- PERFORMANCE_REPORT.md;
- FINAL_GATE.md.

Final answer must lead with outcome, link the route and reports, list verification evidence, known limitations and GO/PARTNER/NO-GO recommendation. Do not claim production readiness.

Start now with LS-000 only.

---

## Короткая версия prompt

Если весь контекст уже загружен:

> Выполни ArchiDom Layout Studio KORA MVP строго по docs/product-intelligence/layout-studio-mvp/README.md. Начни только с LS-000 и Gate 0. Не пиши product code при неподтверждённых координатах KORA. Не меняй production database, auth или существующие dirty files. Следуй LS IDs, Day 5 gate, acceptance plan и cut order.

