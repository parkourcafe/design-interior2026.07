# ArchiDom Layout Studio — пакет запуска двухнедельного KORA MVP

Дата: 4 августа 2026 года

Статус: **ready for owner approval; implementation not started**

Цель пакета — дать Codex полный, непротиворечивый контракт для создания за 10 рабочих дней внутреннего браузерного прототипа Layout Studio на реальном объекте KORA Liquid Station.

## 1. Что именно можно построить за две недели

Можно построить проверяемый KORA-only MVP:

- один этаж;
- один вариант планировки;
- точные стены, двери и проёмы;
- отдельная колонна 250 × 250 мм;
- барная стойка, центральная мойка и оборудование;
- числовой инспектор размеров и координат;
- базовые привязки;
- 2D-план;
- производная 3D-сцена;
- простые материалы и свет;
- локальные draft/checkpoint/version;
- JSON, SVG, PNG и GLB export;
- печатный summary;
- демонстрационный diff двух версий.

Нельзя честно построить за две недели:

- полный аналог RemPlanner;
- все 25 профессиональных листов;
- production-ready CAD/BIM;
- сложный MEP;
- автоматическую смету и каталог рынка;
- совместное realtime-редактирование;
- мобильный профессиональный редактор;
- production migration и широкую публикацию.

## 2. Обязательный порядок чтения

1. [Исследование RemPlanner и целевая архитектура](../research/ARCHIDOM_LAYOUT_STUDIO_CLEAN_ROOM_ARCHITECTURE_v0.1_2026-08-04.md)
2. [MVP Product Requirements](./01_MVP_PRODUCT_REQUIREMENTS.md)
3. [Proposed ADR](./02_PROPOSED_ADR_0006_NATIVE_LAYOUT_STUDIO_SPIKE.md)
4. [Техническая архитектура MVP](./03_MVP_TECHNICAL_ARCHITECTURE.md)
5. [Доменный и файловый контракт](./04_DOMAIN_AND_FILE_CONTRACT.md)
6. [Исполняемое ТЗ для Codex](./05_CODEX_EXECUTION_SPEC.md)
7. [План 10 рабочих дней](./06_EXECUTION_PLAN_10_DAYS.md)
8. [Acceptance test plan](./07_ACCEPTANCE_TEST_PLAN.md)
9. [KORA evidence manifest](./08_KORA_EVIDENCE_MANIFEST.md)
10. [Risk register](./09_RISK_REGISTER.md)
11. [GO/NO-GO checklist](./10_GO_NO_GO_CHECKLIST.md)
12. [Стартовый prompt для Codex](./11_CODEX_START_PROMPT.md)
13. [Requirements Traceability Matrix](./12_REQUIREMENTS_TRACEABILITY.md)
14. [Шаблоны implementation reports](./13_IMPLEMENTATION_REPORT_TEMPLATES.md)

Машиночитаемая схема:

- [layout-document-v0.1.schema.json](./layout-document-v0.1.schema.json)

## 3. Источники истины

При конфликте действует порядок:

1. root/repo AGENTS.md;
2. действующий Product Charter v0.4;
3. Architecture v1 и принятые ADR;
4. Proposed ADR из этого пакета только в границе timeboxed experiment;
5. MVP Product Requirements;
6. Domain and File Contract;
7. Codex Execution Spec;
8. план и вспомогательные документы.

Proposed ADR не меняет принятый Product Charter автоматически.

## 4. Зафиксированные допущения

- Название модуля: ArchiDom Layout Studio.
- Формат: internal development preview.
- Платформа: desktop Chrome; Safari/Edge — smoke only.
- Канонические единицы: целые миллиметры.
- Объект: KORA Liquid Station.
- Геометрия MVP: прямые сегменты и преимущественно ортогональный план.
- 2D renderer: React SVG behind a renderer boundary.
- 3D renderer: Three.js behind a scene adapter.
- Persistence: test/local adapter, без production database.
- Доступ: существующая authenticated shell либо dev-only route за feature flag.
- AI не входит.
- Данные RemPlanner не импортируются через скрытые API.

## 5. Блокирующий Gate 0

До первой строки product code необходимо:

- сохранить текущий dirty-worktree inventory;
- не удалять и не откатывать чужие изменения;
- подтвердить authoritative размеры KORA;
- дать stable IDs стенам, дверям, колонне и оборудованию;
- подтвердить, что колонна не пересекается со стойкой и мойкой;
- подтвердить координаты дверей и оборудования;
- получить явный GO на Proposed ADR как на эксперимент;
- подтвердить право добавить Three.js либо выбрать простой box-scene adapter без новой зависимости.

Если Gate 0 не пройден, разрешены только pure domain fixtures и тесты.

## 6. Definition of success

На демо десятого рабочего дня пользователь:

1. открывает KORA Liquid Station;
2. видит точный 2D-план;
3. выбирает стену, дверь, колонну или оборудование;
4. меняет допустимое числовое значение;
5. видит согласованное обновление 2D и 3D;
6. сохраняет checkpoint;
7. создаёт вторую версию;
8. видит краткий diff;
9. выгружает JSON, SVG, PNG и GLB;
10. открывает печатный summary с номером exact version.

## 7. Definition of failure

Эксперимент считается NO-GO, если:

- 2D и 3D используют разные источники данных;
- размеры хранятся как плавающие display-значения;
- колонна или двери рисуются только декоративно;
- сохранение версии перезаписывает предыдущую;
- KORA можно показать только заранее подготовленной картинкой;
- для работы нужны production credentials;
- smoke flow не воспроизводится после чистого запуска;
- lint, typecheck, tests или build не проходят.

## 8. Как запустить работу

После заполнения GO/NO-GO checklist передать Codex содержимое файла 11_CODEX_START_PROMPT.md. Codex обязан начать с baseline audit и Gate 0, а не с установки библиотек или рисования интерфейса.

