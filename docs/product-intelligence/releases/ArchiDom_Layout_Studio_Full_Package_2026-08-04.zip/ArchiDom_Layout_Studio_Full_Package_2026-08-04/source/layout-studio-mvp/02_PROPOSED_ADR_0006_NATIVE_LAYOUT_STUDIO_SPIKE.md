# Proposed ADR-0006 — Timeboxed Native Layout Studio Spike

Дата: 4 августа 2026 года

Статус: **proposed; owner approval required**

## Контекст

Product Charter v0.4 фиксирует CAD/BIM и размерную геометрию как внешние возможности. Это решение защищает текущий authenticated pilot от резкого расширения scope.

При работе над KORA Liquid Station выявлена практическая потребность:

- точный 2D;
- связанный 3D;
- фиксированные архитектурные ограничения;
- собственные версии;
- передача exact geometry в M3.

RemPlanner функционально подтверждает ценность такого workflow, но не предоставляет подходящий integration contract для embedding в ArchiDom.

## Решение

Разрешить **только timeboxed 10-working-day experiment** ArchiDom Layout Studio при следующих условиях:

1. Эксперимент не изменяет публичное обещание Product Charter.
2. Эксперимент не использует production database или production client data.
3. Эксперимент работает на KORA fixture и минимум одном synthetic fixture.
4. Код создаётся в новых изолированных модулях.
5. Каноническая модель независима от React, Next.js, Supabase и Three.js.
6. 2D и 3D являются projections одной модели.
7. Published local snapshots immutable.
8. Любая интеграция с Project Intelligence выполняется через port/test adapter.
9. Не создаются migrations.
10. На десятый день принимается отдельное GO/PARTNER/NO-GO решение.

## Что этим решением не принимается

- нативный CAD/BIM как production scope;
- обязательство достичь parity с RemPlanner;
- покупка SDK;
- новый коммерческий тариф;
- production storage;
- realtime collaboration;
- MEP или сметы;
- публичная дата релиза.

## Архитектурные последствия

Положительные:

- реальный evidence вместо абстрактной оценки;
- проверка сложности geometry kernel;
- KORA fixture для будущих тестов;
- возможность обоснованного build/license решения;
- точный contract между геометрией и Project Memory.

Отрицательные:

- две недели отвлекают команду от текущего P0;
- появятся экспериментальные зависимости и код;
- прототип легко ошибочно принять за готовый CAD;
- может потребоваться удалить spike после NO-GO.

## Граница модулей

Разрешены новые пути:

~~~text
lib/layout-studio/domain/**
lib/layout-studio/application/**
lib/layout-studio/adapters/local/**
components/layout-studio/**
app/app/layout-studio/**
fixtures/layout-studio/**
tests/layout-studio/**
docs/product-intelligence/layout-studio-mvp/**
~~~

Изменение существующих shared contracts допускается только additive и после отдельной фиксации в change log.

Запрещены:

~~~text
supabase/migrations/**
production auth/RLS policy
existing projectceo schema/RPC semantics
public landing promises
mobile release configuration
current M1 intake behavior
~~~

## Техническое решение MVP

- canonical integer millimeters;
- pure TypeScript domain;
- React SVG для 2D MVP;
- Three.js adapter для 3D;
- local repository adapter;
- deterministic JSON serialization;
- SHA-256 semantic hash;
- SVG/PNG/GLB export;
- browser print summary;
- desktop Chrome target.

React SVG выбран не как долгосрочное решение, а как самый быстрый способ проверить professional interaction на небольшой сцене. Renderer boundary должна позволить заменить его на Canvas/WebGL без миграции domain.

## Критерии GO после эксперимента

GO возможен, если:

- KORA fixture проходит critical acceptance;
- one-model 2D/3D доказан;
- geometry code тестируем и не связан с UI;
- производительность достаточна;
- estimate следующего этапа сужен;
- build path выгоднее доступных SDK либо даёт уникальную ценность.

PARTNER выбирается, если:

- UX и Project Memory ценны;
- свой kernel слишком дорог;
- найден SDK с приемлемой лицензией, data plane и export.

NO-GO выбирается, если:

- геометрия остаётся нестабильной;
- KORA требует ручных обходов;
- value не оправдывает команду;
- experiment мешает обязательному authenticated pilot;
- невозможно обеспечить права на assets/data.

## Rollback

При NO-GO:

- feature flag выключается;
- route удаляется отдельным контролируемым change;
- pure fixtures, evidence и архитектурные выводы сохраняются;
- dependency удаляется, если больше не используется;
- production schema не требует rollback, потому что migration запрещена.

## Требуемое одобрение

Owner подтверждает:

- timebox 10 рабочих дней;
- KORA-only scope;
- отсутствие production обещания;
- право остановить работу при провале Gate 0 или Day 5.

