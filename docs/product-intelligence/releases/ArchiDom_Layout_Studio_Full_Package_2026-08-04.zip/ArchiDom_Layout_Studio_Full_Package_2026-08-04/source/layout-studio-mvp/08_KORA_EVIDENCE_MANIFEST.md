# KORA Liquid Station — Evidence Manifest для Layout Studio MVP

Дата: 4 августа 2026 года

Статус: **input inventory; coordinate freeze pending**

## 1. Правило авторитетности

При конфликте:

1. подписанный/подтверждённый размерный план;
2. последний SVG/PDF план с размерами;
3. equipment schedule;
4. прямое подтверждение владельца с датой;
5. визуальные изображения;
6. AI-референсы.

AI-картинка никогда не меняет размерную геометрию.

## 2. Source registry

| Source ID | Тип | Содержание | Authority | Статус |
|---|---|---|---:|---|
| KORA-PLAN-FF-001 | Архитектурный план | Первый этаж, Tenant 12 и окружение | 1 | Provided; exact revision freeze required |
| KORA-PLAN-SVG-001 | SVG | Размерный план Liquid Station | 2 | Provided |
| KORA-PLAN-PDF-001 | PDF | План проекта | 2 | Provided |
| KORA-EQUIP-001 | XLSX | Equipment schedule Liquid Station | 3 | Provided; row-level normalization required |
| KORA-BRIEF-001 | Markdown | Bar design brief | 3 | Provided |
| KORA-BACKBAR-001 | Image/3D | Задняя линия оборудования | 5 | Provided |
| KORA-OWNER-20260804 | Human confirmation | Колонна, двери, стены, пол, потолок, мойка | 4 | Must be converted to coordinate freeze |
| KORA-REF-LS-001 | Images | Liquid Station visual direction | 6 | Inspiration only |
| KORA-REMPLANNER-001 | External project | Проверочная модель в RemPlanner | 5 | Visual cross-check only; no hidden API |

В fixture используются sanitized source IDs, не local paths.

## 3. Подтверждённые архитектурные правила

| Rule ID | Правило | Статус |
|---|---|---|
| KR-001 | Бар расположен в Tenant 12 и фронтом обращён к основному входному потоку | Confirmed concept |
| KR-002 | Помещение не открыто со всех сторон | Confirmed |
| KR-003 | Доступ персонала сохраняется через существующие двери | Confirmed |
| KR-004 | Существующие двери нельзя удалять или переносить по design reference | Confirmed |
| KR-005 | Одна сторона является стеной; присутствует боковой возврат/угол | Confirmed; exact geometry from plan |
| KR-006 | Потолок ровный бетонный, без новых бетонных блоков/балок | Confirmed |
| KR-007 | Пол матовый polished concrete с локальной индонезийской плиткой | Confirmed material intent |
| KR-008 | Нельзя добавлять глянцевый общий пол | Confirmed |
| KR-009 | Конструктивная колонна отдельная, от пола до потолка | Confirmed |
| KR-010 | Сечение колонны 250 × 250 мм | Confirmed by owner/plan tool |
| KR-011 | Колонна не стоит на барной стойке и не является частью стола | Confirmed |
| KR-012 | Центральная двойная мойка — самостоятельный объект | Confirmed |
| KR-013 | Две команды подходят к мойке с двух сторон | Confirmed operational intent |
| KR-014 | Заднее оборудование остаётся у стены в заданной последовательности | Confirmed |
| KR-015 | Рабочая поверхность требует равномерного task lighting | Confirmed |
| KR-016 | Decorative light/tube может идти по стене, потолку и колонне, но не меняет конструктив | Confirmed design intent |
| KR-017 | Правая видимая стена/угол является активной брендовой точкой | Confirmed design intent |
| KR-018 | Liquid Station должен читаться как современная liquid/fuel station, без буквального копирования бензоколонки | Confirmed concept |

## 4. Equipment control schedule

Предварительно извлечено из переданного изображения/ведомости. До fixture значения сверяются с XLSX.

| ID | Объект | Width × Depth × Height, мм | Статус |
|---|---|---:|---|
| EQ-01 | Нержавеющий шкаф/кофейная станция | 1660 × 700 × 850 | Verify against XLSX |
| EQ-02 | Холодильный/морозильный модуль | 1800 × 700 × 850 | Verify against XLSX |
| GAP-01 | Дверной/свободный проход | 600 width | Verify exact parent wall/position |
| EQ-03 | Рабочий стол | 950 × 700 × 850 | Verify against XLSX |
| EQ-04 | Высокий холодильный модуль | 1900 × 700 × 2092 shown in table | Height conflict suspected; owner/vendor confirmation required |
| EQ-05 | Высокий однодверный холодильник | 540 × 700 × 1540 | Verify against XLSX |

Предварительная суммарная длина последовательности с проходом: 7450 мм. Это контроль, не замена plan dimension.

## 5. Blocking coordinate freeze

До KORA fixture заполнить таблицу:

| Entity ID | Anchor | X, мм | Y, мм | W/L, мм | D/T, мм | H, мм | Rotation | Source ID | Confirmed by |
|---|---|---:|---:|---:|---:|---:|---:|---|---|
| wall.kora.* | node-to-node | TBD | TBD | TBD | TBD | TBD | — | KORA-PLAN-* | TBD |
| opening.kora.* | parent wall + offset | TBD | TBD | TBD | — | TBD | — | KORA-PLAN-* | TBD |
| column.kora.center | center | TBD | TBD | 250 | 250 | floor clear height | 0 | KORA-OWNER-20260804 | Owner |
| object.kora.sink | center | TBD | TBD | TBD | TBD | TBD | TBD | KORA-PLAN/EQUIP | TBD |
| object.kora.eq01 | center | TBD | TBD | 1660 | 700 | 850 | TBD | KORA-EQUIP-001 | TBD |

Room depth/расстояние до стены, которое владелец уточнил как 3000 мм, должно быть привязано к двум конкретным reference anchors. До этого оно не считается coordinate constraint.

## 6. Что не переносится из изображений

- случайно добавленные стены;
- дополнительные колонны;
- дополнительные бетонные потолочные объёмы;
- изменённые двери;
- оборудование в новом порядке;
- колонна на стойке;
- видимая сверху мойка как декоративный объект;
- глянцевый пол;
- чёрная сцена без рабочего света;
- размеры, сгенерированные AI.

## 7. Fixture sanitization

Перед commit:

- убрать absolute paths;
- убрать email и account IDs;
- убрать private RemPlanner links;
- заменить filenames на Source IDs;
- не включать исходные изображения в public assets;
- разрешённые thumbnails хранить только после license/provenance check;
- geometry values сопровождать sourceRef;
- unresolved value помечать warning, не придумывать.

## 8. Gate 0 acceptance

- [ ] выбрана exact revision первого этажа;
- [ ] зафиксирован внутренний контур Tenant 12;
- [ ] зафиксирована clear height;
- [ ] все двери имеют parent wall/offset/width/height;
- [ ] колонна имеет X/Y;
- [ ] мойка имеет X/Y/W/D/H;
- [ ] equipment schedule сверена с XLSX;
- [ ] конфликт EQ-04 height решён;
- [ ] 3000 мм привязано к anchors;
- [ ] owner подтвердил coordinate table.

