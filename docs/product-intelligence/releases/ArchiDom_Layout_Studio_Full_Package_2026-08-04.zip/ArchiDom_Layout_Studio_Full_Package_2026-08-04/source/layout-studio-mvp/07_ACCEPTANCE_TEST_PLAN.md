# ArchiDom Layout Studio — Acceptance Test Plan

Дата: 4 августа 2026 года

Статус: **test contract**

Приоритеты:

- P0 — без теста MVP не принимается;
- P1 — должен пройти, но может быть исправлен в controlled closeout;
- P2 — полезный post-spike signal.

## 1. Contract и units

| ID | P | Проверка | Ожидаемый результат |
|---|---:|---|---|
| LS-AT-001 | P0 | Валидный simple fixture | Schema pass |
| LS-AT-002 | P0 | Валидный KORA fixture | Schema pass |
| LS-AT-003 | P0 | Decimal canonical coordinate | Rejected |
| LS-AT-004 | P0 | Duplicate stable ID | Blocking issue |
| LS-AT-005 | P0 | Missing referenced node | Blocking issue |
| LS-AT-006 | P0 | Display mm → m² | Canonical data unchanged |

## 2. Геометрия KORA

| ID | P | Проверка | Ожидаемый результат |
|---|---:|---|---|
| LS-AT-010 | P0 | Structural contour | Matches coordinate freeze |
| LS-AT-011 | P0 | Column | 250 × 250 мм, separate entity |
| LS-AT-012 | P0 | Column 3D | Floor-to-ceiling at frozen position |
| LS-AT-013 | P0 | Doors/openings | Attached to correct wall and position |
| LS-AT-014 | P0 | Rear equipment sequence | Matches frozen schedule |
| LS-AT-015 | P0 | Central double sink | Separate from column/counter |
| LS-AT-016 | P0 | Closed sides/access | Matches actual room constraints |
| LS-AT-017 | P0 | Zero-length wall | Rejected |
| LS-AT-018 | P0 | Opening outside wall | Rejected |
| LS-AT-019 | P1 | Clearance overlap | Warning with related IDs |

## 3. 2D

| ID | P | Проверка | Ожидаемый результат |
|---|---:|---|---|
| LS-AT-020 | P0 | Open KORA route | Plan visible and fitted |
| LS-AT-021 | P0 | Select wall/door/column/object | Exact object selected |
| LS-AT-022 | P0 | Pan/zoom/fit | No data change |
| LS-AT-023 | P0 | Dimension labels | Values match canonical mm |
| LS-AT-024 | P1 | Layer toggle | Only presentation changes |
| LS-AT-025 | P1 | Selected highlight | Clearly visible |
| LS-AT-026 | P1 | SVG golden | No unexplained regression |

## 4. Editing

| ID | P | Проверка | Ожидаемый результат |
|---|---:|---|---|
| LS-AT-030 | P0 | Move permitted equipment +100 мм | stateRevision +1 |
| LS-AT-031 | P0 | Drag locked column | No change + controlled message |
| LS-AT-032 | P0 | Drag locked door | No change + controlled message |
| LS-AT-033 | P0 | Invalid numeric value | Last valid state preserved |
| LS-AT-034 | P0 | Undo | Previous semantic state |
| LS-AT-035 | P0 | Redo | Reapplied semantic state |
| LS-AT-036 | P0 | Stale expected revision | STATE_STALE |
| LS-AT-037 | P1 | Repeated idempotency key | Same logical result |

## 5. 3D

| ID | P | Проверка | Ожидаемый результат |
|---|---:|---|---|
| LS-AT-040 | P0 | Switch 2D → 3D | Same document revision |
| LS-AT-041 | P0 | Wall/opening/column count | Matches derived projection |
| LS-AT-042 | P0 | Equipment movement | Same change appears in 3D |
| LS-AT-043 | P0 | Hide ceiling | Camera view changes, data does not |
| LS-AT-044 | P1 | Reset camera | Deterministic default view |
| LS-AT-045 | P0 | WebGL unavailable | Controlled fallback, no crash |
| LS-AT-046 | P1 | Component unmount | GPU resources disposed |

## 6. Materials and lights

| ID | P | Проверка | Ожидаемый результат |
|---|---:|---|---|
| LS-AT-050 | P0 | Matte concrete | Rough, non-glossy appearance |
| LS-AT-051 | P0 | Stainless versus patina | Visually distinguishable |
| LS-AT-052 | P0 | Neutral task light | Work surface readable |
| LS-AT-053 | P1 | Warm decorative light | Distinct from task light |
| LS-AT-054 | P0 | Assignment change | Canonical material ID changed |

## 7. Persistence and versions

| ID | P | Проверка | Ожидаемый результат |
|---|---:|---|---|
| LS-AT-060 | P0 | Autosave + reload | Draft restored |
| LS-AT-061 | P0 | Create checkpoint | Recoverable snapshot |
| LS-AT-062 | P0 | Publish Version A | Immutable version + hash |
| LS-AT-063 | P0 | Edit after Version A | New draft only |
| LS-AT-064 | P0 | Publish Version B | New ID/hash |
| LS-AT-065 | P0 | Load Version A after B | Original content unchanged |
| LS-AT-066 | P0 | Diff A→B | Exact entity/field reported |
| LS-AT-067 | P1 | Storage quota error | Controlled error, session retained |
| LS-AT-068 | P0 | Same semantic content twice | Same semantic hash |

## 8. Export

| ID | P | Проверка | Ожидаемый результат |
|---|---:|---|---|
| LS-AT-070 | P0 | JSON export | Schema-valid exact version |
| LS-AT-071 | P0 | SVG export | Opens, exact plan, no UI overlay |
| LS-AT-072 | P1 | PNG export | Opens at requested size |
| LS-AT-073 | P0 | GLB export | Valid, scale in meters |
| LS-AT-074 | P0 | Print summary | Version/hash/warnings/disclaimer |
| LS-AT-075 | P0 | Sidecar manifest | Checksums and exact version |
| LS-AT-076 | P0 | Privacy scan | No path/email/token/private URL |
| LS-AT-077 | P0 | Export Version A after B exists | Artifact remains Version A |

## 9. Integration and safety

| ID | P | Проверка | Ожидаемый результат |
|---|---:|---|---|
| LS-AT-080 | P0 | Feature flag off | Preview unavailable |
| LS-AT-081 | P0 | No production credentials | Demo works |
| LS-AT-082 | P0 | Supabase migration diff | No new migration |
| LS-AT-083 | P0 | Existing auth/intake smoke | No regression |
| LS-AT-084 | P0 | Domain dependency scan | No UI/runtime imports |
| LS-AT-085 | P0 | Full lint/typecheck/test/build | All green |
| LS-AT-086 | P1 | Browser reload mid-edit | Last saved draft recovered |
| LS-AT-087 | P0 | Unrelated dirty files | Preserved |

## 10. Performance

| ID | P | Проверка | Ожидаемый результат |
|---|---:|---|---|
| LS-AT-090 | P1 | Simple numeric command | Under 100 ms target |
| LS-AT-091 | P1 | KORA plan interaction | No sustained visible jank |
| LS-AT-092 | P1 | KORA 3D first useful frame | Under 5 s target machine |
| LS-AT-093 | P2 | 100 equipment boxes | Benchmark recorded |
| LS-AT-094 | P1 | Memory after 10 view switches | No unbounded growth |

## 11. Manual demo acceptance

Owner проходит:

- [ ] точный план;
- [ ] двери;
- [ ] колонна 250 × 250;
- [ ] заднее оборудование;
- [ ] центральная мойка;
- [ ] 2D/3D consistency;
- [ ] изменение одного объекта;
- [ ] undo/redo;
- [ ] Version A/B;
- [ ] diff;
- [ ] JSON/SVG/GLB;
- [ ] print summary.

## 12. Evidence

Для каждого P0:

- automated test name либо manual step;
- expected;
- actual;
- PASS/FAIL/BLOCKED;
- artifact/screenshot path без PII;
- defect ID при fail.

MVP принимается только при 100% P0 PASS. BLOCKED считается FAIL до отдельного owner waiver.

