# ArchiDom Layout Studio KORA MVP — Risk Register

Дата: 4 августа 2026 года

Статус: **active during spike**

Шкала:

- Probability: L/M/H;
- Impact: L/M/H/Critical.

| ID | Риск | P | Impact | Trigger | Mitigation | Owner |
|---|---|---:|---:|---|---|---|
| LS-R01 | Две недели воспринимаются как срок полного RemPlanner | H | Critical | Добавляются листы/MEP/сметы | Жёсткий MVP и cut order | Product owner |
| LS-R02 | Размеры KORA противоречат друг другу | H | Critical | Plan/XLSX/chat не совпадают | Gate 0 coordinate freeze | Owner + architect |
| LS-R03 | Колонна снова моделируется частью стойки | M | Critical | Entity/mesh parent неверен | Separate locked Column entity + P0 test | Geometry |
| LS-R04 | 2D и 3D расходятся | M | Critical | Отдельный scene state | One canonical model, derived DTO | Architecture |
| LS-R05 | Geometry kernel сложнее timebox | H | H | Day 3 KORA invalid | Orthogonal/simple-face scope; Day 5 stop | Geometry |
| LS-R06 | Three.js ломает текущий build | M | H | Dependency conflict | Day 1 primary-doc check; isolated adapter | Integrator |
| LS-R07 | Dirty worktree приводит к потере чужих изменений | M | Critical | Shared file conflict | Baseline inventory; additive paths; no reset | Integrator |
| LS-R08 | Прототип требует production DB | L | Critical | Persistence task expands | Local repository only | Architecture |
| LS-R09 | Local storage quota/data loss | M | H | Save failure | Size check, controlled error, JSON export | Application |
| LS-R10 | GLB масштаб неверен | M | H | mm exported as meters | Explicit /1000 boundary + validator test | 3D |
| LS-R11 | Экспорт содержит private paths/PII | M | Critical | Manifest leak | Sanitization + privacy test | QA |
| LS-R12 | SVG renderer тормозит | L/M | M | Visible jank KORA | Benchmark; renderer boundary | 2D |
| LS-R13 | WebGL недоступен | L/M | M | Context failure | Controlled 2D fallback | 3D |
| LS-R14 | Материалы отвлекают от геометрии | H | M | Texture work before Day 5 | Colors/PBR only; cut textures | Product |
| LS-R15 | Неподтверждённое оборудование кодируется как факт | M | H | Fixture has invented value | sourceRef + warnings + owner freeze | Fixture |
| LS-R16 | Current Charter нарушен без решения | M | H | Публичное обещание native CAD | Proposed ADR experiment only | Product/Architecture |
| LS-R17 | UI polish вытесняет tests | H | H | Day 8 critical tests absent | Daily gates; Day 10 feature freeze | Lead |
| LS-R18 | AI добавляется в MVP | M | H | Request for generated interior | Explicit non-goal | Product |
| LS-R19 | One user prototype выдают за multi-user | M | M | Guest/realtime request | Clear labeling and backlog | Product |
| LS-R20 | Нет второго fixture | M | M | Logic hardcoded to KORA | simple-room mandatory | Domain |
| LS-R21 | Published version мутирует | L/M | Critical | Object reference reused | Deep immutable snapshot + tests | Application |
| LS-R22 | Browser print называют рабочим чертежом | M | H | No disclaimer | Mandatory prototype disclaimer | Delivery |
| LS-R23 | Full repo baseline уже красный | M | H | Pre-existing failure | Record baseline; isolate new failures; stop if ambiguous | Integrator |
| LS-R24 | App route становится публичным | L/M | Critical | Feature flag/auth failure | Server flag + route smoke | Security |
| LS-R25 | Код spike становится permanent без решения | H | H | No final gate | Day 10 GO/PARTNER/NO-GO mandatory | Owner |

## 1. Top five

1. LS-R01 — scope misrepresentation.
2. LS-R02 — uncertain KORA dimensions.
3. LS-R04 — 2D/3D divergence.
4. LS-R07 — dirty worktree collision.
5. LS-R21 — mutable publication.

## 2. Escalation rule

Работа останавливается, если:

- Critical risk triggered и mitigation не выполняется;
- появляется production data access;
- coordinate freeze не может быть принят;
- one-model principle нарушается;
- Day 5 нет working KORA 3D.

## 3. Daily review

Каждый day handoff обновляет:

- new risks;
- triggered risks;
- mitigation status;
- accepted residual risk;
- owner decision.

