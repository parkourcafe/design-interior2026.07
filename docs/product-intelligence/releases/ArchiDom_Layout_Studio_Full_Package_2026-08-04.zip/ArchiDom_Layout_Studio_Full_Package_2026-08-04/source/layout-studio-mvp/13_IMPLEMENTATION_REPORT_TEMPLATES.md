# ArchiDom Layout Studio MVP — шаблоны implementation reports

Дата: 4 августа 2026 года

## 1. BASELINE_REPORT.md

~~~text
# Layout Studio MVP — Baseline Report

Date:
Commit/branch:
Operator:

## Repository state
- Current HEAD:
- Dirty tracked files:
- Untracked files:
- Overlap with proposed owned paths:

## Commands before change
| Command | Result | Evidence |

## Runtime
- Node:
- Next:
- React:
- TypeScript:
- Vitest:

## Constraints found

## Gate 0 status
PASS / BLOCKED

## Blockers
~~~

## 2. KORA_COORDINATE_FREEZE.md

~~~text
# KORA Coordinate Freeze

Date:
Plan revision:
Canonical origin:
X-axis direction:
Y-axis direction:
Units: mm
Floor elevation:
Clear height:

| Entity ID | Type | Anchor | X | Y | W/L | D/T | H | Rotation | Source | Owner confirmed |

## Equipment sequence
| Order | Entity ID | W | D | H | Gap after | Source |

## Known warnings

## Owner approval
Name:
Date:
Decision:
~~~

## 3. DEPENDENCY_DECISION.md

~~~text
# Layout Studio Dependency Decision

## Need

## Existing repo capability

## Candidate

## Official compatibility evidence

## Bundle/security/license impact

## Alternatives considered

## Decision

## Rollback
~~~

## 4. IMPLEMENTATION_REPORT.md

~~~text
# Layout Studio MVP — Implementation Report

Date:
Final commit:
Feature flag:
Route:

## Outcome

## Implemented LS work items

## Changed files

## Architecture
- Canonical model:
- 2D adapter:
- 3D adapter:
- Persistence:
- Exports:

## KORA fixture

## Demo in 10 minutes
1.

## Known limitations

## Deferred backlog

## Unrelated dirty work preservation
~~~

## 5. VERIFICATION_REPORT.md

~~~text
# Layout Studio MVP — Verification Report

## Automated commands
| Command | Result | Duration | Notes |

## Acceptance
| Test ID | Result | Evidence | Defect |

## Browser smoke

## Export validation

## Privacy scan

## Regressions

## Final P0 count
PASS:
FAIL:
BLOCKED:
~~~

## 6. PERFORMANCE_REPORT.md

~~~text
# Layout Studio MVP — Performance Report

Machine/browser:
Fixture size:

| Metric | Target | Actual | Result |
| Simple command | <100 ms | | |
| KORA load | <2 s after JS load | | |
| 3D first useful frame | <5 s | | |
| Ten 2D/3D switches | no unbounded memory | | |

## Method

## Bottlenecks

## Recommendation
~~~

## 7. FINAL_GATE.md

~~~text
# Layout Studio MVP — Final Gate

Date:

## Product result

## Technical result

## Acceptance result

## Remaining critical risks

## Three-year implication

## Recommendation
GO / PARTNER / NO-GO / EXTEND

## Required next decision

## Owner sign-off
~~~

## 8. Report rules

- Report содержит actual evidence, не обещания.
- FAIL нельзя переименовать в known limitation, если это P0.
- Pre-existing failure отделяется от introduced failure.
- Absolute paths, email, tokens и private project URLs удаляются.
- Screenshots используют sanitized fixture.
- Final Gate не заявляет production readiness.

